#requires -Version 5.1
# Independent compatibility implementation, inspired by the documented PowerShell 7.6 API.
# Requires .NET Framework 4.8 on Windows PowerShell 5.1. No PowerShell 7 installation required.
# Json.NET and WinHttpHandler assemblies are supplied in the adjacent lib folder.

Import-Module Microsoft.PowerShell.Utility -ErrorAction Stop

function Invoke-RestMethod51 {
    <#
    .SYNOPSIS
    PowerShell 7-style REST requests on Windows PowerShell 5.1 / .NET Framework 4.8.
    .DESCRIPTION
    Supports HTTP/1.0, HTTP/1.1 and negotiated HTTP/2, plus OS-dependent TLS 1.3.
    This is a compatibility implementation, not the
    original Microsoft cmdlet. See README.md for supported features and differences.
    A supplied WebRequestSession retains cookies, settings and cached HttpClient instances.
    .EXAMPLE
    Invoke-RestMethod51 https://api.example.com/items -StatusCodeVariable status
    .EXAMPLE
    Invoke-RestMethod51 https://api.example.com/items -Method Post -ContentType application/json -Body '{"name":"test"}'
    #>
    [CmdletBinding(DefaultParameterSetName = 'StandardMethod')]
    param(
        [Parameter(Mandatory, Position = 0)][ValidateNotNullOrEmpty()][uri] $Uri,
        [Alias('FL')][switch] $FollowRelLink,
        [Alias('ML')][ValidateRange(1, 2147483647)][int] $MaximumFollowRelLink = [int]::MaxValue,
        [Alias('RHV')][string] $ResponseHeadersVariable,
        [string] $StatusCodeVariable,
        [string] $ResponseHttpVersionVariable,
        [switch] $UseBasicParsing,
        [version] $HttpVersion = '1.1',
        [Microsoft.PowerShell.Commands.WebRequestSession] $WebSession,
        [Alias('SV')][string] $SessionVariable,
        [switch] $AllowUnencryptedAuthentication,
        [ValidateSet('None', 'Basic', 'Bearer', 'OAuth')][string] $Authentication = 'None',
        [pscredential] $Credential,
        [switch] $UseDefaultCredentials,
        [string] $CertificateThumbprint,
        [System.Security.Cryptography.X509Certificates.X509Certificate] $Certificate,
        [switch] $SkipCertificateCheck,
        [ValidateSet('Default', 'Tls', 'Tls11', 'Tls12', 'Tls13')][string[]] $SslProtocol = @('Default'),
        [securestring] $Token,
        [string] $UserAgent,
        [switch] $DisableKeepAlive,
        [Alias('TimeoutSec')][ValidateRange(0, 2147483647)][int] $ConnectionTimeoutSeconds = 0,
        [ValidateRange(0, 2147483647)][int] $OperationTimeoutSeconds = 0,
        [System.Collections.IDictionary] $Headers,
        [switch] $SkipHeaderValidation,
        [switch] $AllowInsecureRedirect,
        [ValidateRange(0, 2147483647)][int] $MaximumRedirection = 50,
        [ValidateRange(0, 2147483647)][int] $MaximumRetryCount = 0,
        [switch] $PreserveAuthorizationOnRedirect,
        [ValidateRange(1, 2147483647)][int] $RetryIntervalSec = 5,
        [Parameter(ParameterSetName = 'StandardMethod')]
        [ValidateSet('Default', 'Get', 'Head', 'Post', 'Put', 'Delete', 'Trace', 'Options', 'Merge', 'Patch')]
        [string] $Method = 'Default',
        [Parameter(Mandatory, ParameterSetName = 'CustomMethod')][Alias('CM')][ValidateNotNullOrEmpty()][string] $CustomMethod,
        [switch] $PreserveHttpMethodOnRedirect,
        [object] $UnixSocket,
        [uri] $Proxy,
        [pscredential] $ProxyCredential,
        [switch] $ProxyUseDefaultCredentials,
        [switch] $NoProxy,
        [Parameter(ValueFromPipeline)][AllowNull()][object] $Body,
        [System.Collections.IDictionary] $Form,
        [string] $ContentType,
        [ValidateSet('chunked', 'compress', 'deflate', 'gzip', 'identity')][string] $TransferEncoding,
        [string] $InFile,
        [string] $OutFile,
        [switch] $PassThru,
        [switch] $Resume,
        [switch] $SkipHttpErrorCheck
    )

    begin {
        Add-Type -AssemblyName System.Net.Http -ErrorAction Stop
        if (-not [System.Net.Http.HttpClientHandler].GetProperty('ServerCertificateCustomValidationCallback') -or -not [System.Net.Http.HttpClientHandler].GetProperty('SslProtocols')) {
            throw 'This function requires .NET Framework 4.8 (or later) on Windows PowerShell 5.1.'
        }
        if (-not ('RestMethod51.Internal' -as [type])) {
            $helperSource = @'
using System;
using System.IO;
using System.Text;
using System.Net;
using System.Net.Http;
using System.Net.Security;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;
using System.Threading.Tasks;
namespace RestMethod51 {
    public sealed class EnvironmentProxy : IWebProxy {
        readonly Uri http, https, all;
        readonly string[] exclusions;
        public ICredentials Credentials { get; set; }
        public EnvironmentProxy(string http, string https, string all, string noProxy) {
            var credentials = new CredentialCache();
            this.http = Parse(http, credentials); this.https = Parse(https, credentials); this.all = Parse(all, credentials);
            Credentials = credentials;
            exclusions = (noProxy ?? "").Split(',');
            foreach (string entry in exclusions)
                if (entry.Contains("/")) throw new NotSupportedException("NO_PROXY CIDR entries are not supported; use an explicit -Proxy or -NoProxy.");
        }
        static Uri Parse(string value, CredentialCache credentials) {
            if (String.IsNullOrWhiteSpace(value)) return null;
            if (!value.Contains("://")) value = "http://" + value;
            var uri = new Uri(value);
            if (uri.Scheme != "http") throw new NotSupportedException("Only HTTP proxy endpoints are supported by .NET Framework. Use -Proxy or -NoProxy.");
            if (!String.IsNullOrEmpty(uri.UserInfo)) {
                string[] info = uri.UserInfo.Split(new char[] { ':' }, 2);
                var builder = new UriBuilder(uri); builder.UserName = ""; builder.Password = ""; uri = builder.Uri;
                credentials.Add(uri, "Basic", new NetworkCredential(Uri.UnescapeDataString(info[0]), info.Length > 1 ? Uri.UnescapeDataString(info[1]) : ""));
            }
            return uri;
        }
        Uri Select(Uri target) { return (target.Scheme == "https" ? https : http) ?? all; }
        public Uri GetProxy(Uri destination) { return IsBypassed(destination) ? destination : Select(destination); }
        public bool IsBypassed(Uri target) {
            if (Select(target) == null) return true;
            foreach (string raw in exclusions) {
                string host = raw.Trim(); if (host.Length == 0) continue;
                if (host == "*") return true;
                int port = -1;
                if (host.StartsWith("[")) {
                    int bracket = host.IndexOf(']');
                    if (bracket < 0) continue;
                    if (host.Length > bracket + 1 && host[bracket + 1] == ':') Int32.TryParse(host.Substring(bracket + 2), out port);
                    host = host.Substring(1, bracket - 1);
                } else if (host.IndexOf(':') == host.LastIndexOf(':') && host.IndexOf(':') >= 0) {
                    int colon = host.LastIndexOf(':'); Int32.TryParse(host.Substring(colon + 1), out port); host = host.Substring(0, colon);
                }
                if (port >= 0 && port != target.Port) continue;
                host = host.TrimStart('*', '.');
                string targetHost = target.DnsSafeHost.Trim('[', ']');
                if (String.Equals(targetHost, host, StringComparison.OrdinalIgnoreCase) || targetHost.EndsWith("." + host, StringComparison.OrdinalIgnoreCase)) return true;
            }
            return false;
        }
    }
    public sealed class HttpResponseException : Exception {
        public HttpResponseMessage Response { get; private set; }
        public HttpResponseException(string message, HttpResponseMessage response) : base(message) { Response = response; }
    }
    public static class Internal {
        public static HttpClientHandler Handler(CookieContainer cookies, bool skipCertificateCheck, int protocols) {
            var h = new HttpClientHandler();
            h.AllowAutoRedirect = false;
            h.CookieContainer = cookies;
            h.AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate;
            if (skipCertificateCheck)
                h.ServerCertificateCustomValidationCallback = delegate(HttpRequestMessage r, X509Certificate2 c, X509Chain ch, SslPolicyErrors e) { return true; };
            h.SslProtocols = (SslProtocols)protocols;
            return h;
        }
        public static HttpResponseMessage Send(HttpClient client, HttpRequestMessage request) {
            return client.SendAsync(request, HttpCompletionOption.ResponseHeadersRead).GetAwaiter().GetResult();
        }
        public static void Copy(Stream input, Stream output, int timeoutSeconds) {
            byte[] buffer = new byte[81920];
            for (;;) {
                Task<int> read = input.ReadAsync(buffer, 0, buffer.Length);
                if (timeoutSeconds > 0) {
                    using (var timer = new System.Threading.CancellationTokenSource()) {
                        Task delay = Task.Delay(TimeSpan.FromSeconds(timeoutSeconds), timer.Token);
                        if (Task.WhenAny(read, delay).GetAwaiter().GetResult() != read) {
                            input.Dispose();
                            throw new TimeoutException("The response stream exceeded OperationTimeoutSeconds.");
                        }
                        timer.Cancel();
                    }
                }
                int count = read.GetAwaiter().GetResult();
                if (count == 0) return;
                output.Write(buffer, 0, count);
            }
        }
        public static string Decode(byte[] bytes, string charset) {
            Encoding encoding = new UTF8Encoding(false);
            if (!String.IsNullOrEmpty(charset)) {
                try { encoding = Encoding.GetEncoding(charset.Trim('"', '\'')); }
                catch (ArgumentException) { }
            }
            using (var stream = new MemoryStream(bytes))
            using (var reader = new StreamReader(stream, encoding, true)) return reader.ReadToEnd();
        }
        // Remove JSON comments without changing comment-looking text inside strings.
        public static string RemoveJsonComments(string json) {
            var result = new StringBuilder(json.Length);
            bool quoted = false, escaped = false;
            for (int i = 0; i < json.Length; i++) {
                char c = json[i];
                if (quoted) {
                    result.Append(c);
                    if (escaped) escaped = false;
                    else if (c == '\\') escaped = true;
                    else if (c == '"') quoted = false;
                } else if (c == '"') { quoted = true; result.Append(c); }
                else if (c == '/' && i + 1 < json.Length && json[i + 1] == '/') {
                    i += 2;
                    while (i < json.Length && json[i] != '\r' && json[i] != '\n') i++;
                    if (i < json.Length) result.Append(json[i]);
                } else if (c == '/' && i + 1 < json.Length && json[i + 1] == '*') {
                    int end = json.IndexOf("*/", i + 2, StringComparison.Ordinal);
                    if (end < 0) throw new FormatException("Unterminated JSON comment.");
                    result.Append(' ');
                    i = end + 1;
                } else result.Append(c);
            }
            return result.ToString();
        }
    }
}
'@
            Add-Type -TypeDefinition $helperSource -ReferencedAssemblies System.Net.Http, System, System.Core -ErrorAction Stop
        }

        # These helpers are local to this invocation; dot-sourcing exports only the main function.
        function ConvertTo-IRM51Query([System.Collections.IDictionary] $Values) {
            $parts = foreach ($key in $Values.Keys) {
                '{0}={1}' -f [System.Net.WebUtility]::UrlEncode([string]$key), [System.Net.WebUtility]::UrlEncode([string]$Values[$key])
            }
            $parts -join '&'
        }

        function Get-IRM51FullPath([string] $Path) {
            $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($Path)
        }

        function New-IRM51WinHttpHandler {
            # WinHTTP is selected for GET content, HTTP/2, or explicit TLS 1.3.
            if (-not ('RestMethod51.WinHttpFactory' -as [type])) {
                $libraryPath = Join-Path $PSScriptRoot 'lib'
                foreach ($assemblyName in @('System.Runtime.CompilerServices.Unsafe','System.Numerics.Vectors','System.Buffers','System.Memory','Microsoft.Bcl.HashCode','System.Net.Http.WinHttpHandler')) {
                    $assemblyPath = Join-Path $libraryPath ($assemblyName + '.dll')
                    if (-not [System.IO.File]::Exists($assemblyPath)) { throw "GET content, HTTP/2 and TLS 1.3 require the DLL files supplied in the complete package. Missing: $assemblyPath" }
                    [void][System.Reflection.Assembly]::LoadFrom($assemblyPath)
                }
                $winHttpSource = @'
using System;
using System.Net;
using System.Net.Http;
using System.Net.Security;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;
namespace RestMethod51 {
    public static class WinHttpFactory {
        public static WinHttpHandler Handler(CookieContainer cookies, bool skipCertificateCheck, int protocols) {
            var h = new WinHttpHandler();
            h.AutomaticRedirection = false;
            h.CookieUsePolicy = CookieUsePolicy.UseSpecifiedCookieContainer;
            h.CookieContainer = cookies;
            h.AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate;
            h.SslProtocols = (SslProtocols)protocols;
            // HttpClient and the response-copy helper own the configured timeouts.
            h.SendTimeout = System.Threading.Timeout.InfiniteTimeSpan;
            h.ReceiveHeadersTimeout = System.Threading.Timeout.InfiniteTimeSpan;
            h.ReceiveDataTimeout = System.Threading.Timeout.InfiniteTimeSpan;
            if (skipCertificateCheck)
                h.ServerCertificateValidationCallback = delegate(HttpRequestMessage r, X509Certificate2 c, X509Chain ch, SslPolicyErrors e) { return true; };
            return h;
        }
    }
}
'@
                Add-Type -TypeDefinition $winHttpSource -ReferencedAssemblies @((Join-Path $libraryPath 'System.Net.Http.WinHttpHandler.dll'), [System.Net.Http.HttpClient].Assembly.Location, 'System', 'System.Core') -ErrorAction Stop
            }
            [RestMethod51.WinHttpFactory]::Handler($session.Cookies, $SkipCertificateCheck, $sslFlags)
        }

        function Get-IRM51Client([bool] $SendCredentials, [bool] $UseWinHttp) {
            # HTTP challenge credentials are distinct from TLS client certificates.
            # Redirects must not rebuild the client just because there are no HTTP credentials to suppress.
            $useHttpCredentials = $SendCredentials -and ($session.UseDefaultCredentials -or $null -ne $session.Credentials)
            $credentialKey = if ($null -ne $session.Credentials) { $session.Credentials.GetHashCode() } else { 0 }
            $proxyKey = if ($null -ne $session.Proxy) { $session.Proxy.GetHashCode() } else { 0 }
            $certKey = (@(foreach ($item in $session.Certificates) { $item.GetCertHashString() })) -join ','
            $environmentKey = if (-not $NoProxy -and -not $session.Proxy) { '{0}|{1}|{2}|{3}' -f $env:HTTP_PROXY,$env:HTTPS_PROXY,$env:ALL_PROXY,$env:NO_PROXY } else { '' }
            $key = '{0}|{1}|{2}|{3}|{4}|{5}|{6}|{7}|{8}|{9}|{10}|{11}' -f $useHttpCredentials, $credentialKey, $session.UseDefaultCredentials, $proxyKey, $NoProxy, $SkipCertificateCheck, $sslFlags, $ConnectionTimeoutSeconds, $certKey, $session.Cookies.GetHashCode(), $environmentKey, $UseWinHttp
            if ($session.PSObject.Properties['RestMethod51Transport']) {
                $cached = $session.RestMethod51Transport
                if ($cached.Key -eq $key) { return $cached.Client }
                $cached.Client.Dispose()
            }
            $handler = if ($UseWinHttp) { New-IRM51WinHttpHandler } else { [RestMethod51.Internal]::Handler($session.Cookies, $SkipCertificateCheck, $sslFlags) }
            try {
                $effectiveProxy = $session.Proxy
                if (-not $NoProxy -and -not $effectiveProxy -and ($env:HTTP_PROXY -or $env:HTTPS_PROXY -or $env:ALL_PROXY)) {
                    $effectiveProxy = New-Object RestMethod51.EnvironmentProxy -ArgumentList ([string]$env:HTTP_PROXY), ([string]$env:HTTPS_PROXY), ([string]$env:ALL_PROXY), ([string]$env:NO_PROXY)
                }
                if ($UseWinHttp) {
                    if (-not $effectiveProxy) { $effectiveProxy = [System.Net.WebRequest]::DefaultWebProxy }
                    if ($NoProxy -or -not $effectiveProxy) { $handler.WindowsProxyUsePolicy = [System.Net.Http.WindowsProxyUsePolicy]::DoNotUseProxy }
                    else { $handler.Proxy = $effectiveProxy; $handler.WindowsProxyUsePolicy = [System.Net.Http.WindowsProxyUsePolicy]::UseCustomProxy }
                } elseif ($NoProxy) { $handler.UseProxy = $false }
                elseif ($effectiveProxy) { $handler.Proxy = $effectiveProxy }
                if ($useHttpCredentials) {
                    if ($UseWinHttp) {
                        $handler.ServerCredentials = if ($session.UseDefaultCredentials) { [System.Net.CredentialCache]::DefaultNetworkCredentials } else { $session.Credentials }
                    } elseif ($session.UseDefaultCredentials) { $handler.UseDefaultCredentials = $true }
                    elseif ($session.Credentials) { $handler.Credentials = $session.Credentials }
                }
                foreach ($cert in $session.Certificates) {
                    if ($UseWinHttp -and $cert -isnot [System.Security.Cryptography.X509Certificates.X509Certificate2]) {
                        [void]$handler.ClientCertificates.Add((New-Object System.Security.Cryptography.X509Certificates.X509Certificate2 -ArgumentList $cert))
                    } else { [void]$handler.ClientCertificates.Add($cert) }
                }
                $client = New-Object System.Net.Http.HttpClient -ArgumentList $handler
                $client.Timeout = if ($ConnectionTimeoutSeconds) { [timespan]::FromSeconds($ConnectionTimeoutSeconds) } else { [System.Threading.Timeout]::InfiniteTimeSpan }
                $cache = [pscustomobject]@{ Key = $key; Client = $client }
                $session | Add-Member -NotePropertyName RestMethod51Transport -NotePropertyValue $cache -Force
                return $client
            } catch { $handler.Dispose(); throw }
        }

        function New-IRM51Content {
            $content = $null
            if ($inputPath) {
                $content = New-Object System.Net.Http.StreamContent -ArgumentList ([System.IO.File]::OpenRead($inputPath))
            } elseif ($null -ne $Form) {
                $multipart = New-Object System.Net.Http.MultipartFormDataContent
                try {
                    foreach ($name in $Form.Keys) {
                        foreach ($value in @($Form[$name])) {
                            if ($value -is [System.IO.FileInfo]) {
                                $part = New-Object System.Net.Http.StreamContent -ArgumentList ($value.OpenRead())
                                $part.Headers.ContentType = [System.Net.Http.Headers.MediaTypeHeaderValue]::Parse('application/octet-stream')
                                try { $multipart.Add($part, [string]$name, $value.Name) } catch { $part.Dispose(); throw }
                            } else {
                                $part = New-Object System.Net.Http.StringContent -ArgumentList ([string]$value), ([System.Text.Encoding]::UTF8)
                                try { $multipart.Add($part, [string]$name) } catch { $part.Dispose(); throw }
                            }
                        }
                    }
                    return ,$multipart
                } catch { $multipart.Dispose(); throw }
            } elseif ($null -ne $Body) {
                if ($Body -is [System.Net.Http.HttpContent]) {
                    # Snapshot the supplied content once so retries do not dispose caller-owned content.
                    $content = New-Object System.Net.Http.ByteArrayContent -ArgumentList (,$httpContentBytes)
                    foreach ($h in $Body.Headers) { [void]$content.Headers.TryAddWithoutValidation($h.Key, [string[]]@($h.Value)) }
                    return $content
                } elseif ($Body -is [System.IO.Stream]) {
                    $content = New-Object System.Net.Http.ByteArrayContent -ArgumentList (,$streamBodyBytes)
                } elseif ($Body -is [byte[]]) {
                    $content = New-Object System.Net.Http.ByteArrayContent -ArgumentList (,$Body)
                } elseif (-not ($Body -is [System.Collections.IDictionary] -and $initialMethod -eq 'GET')) {
                    $text = if ($Body -is [System.Collections.IDictionary]) { ConvertTo-IRM51Query $Body } elseif ($Body -is [System.Xml.XmlNode]) { $Body.OuterXml } else { [string]$Body }
                    $encoding = [System.Text.Encoding]::UTF8
                    if ($Body -is [System.Xml.XmlDocument] -and $Body.FirstChild -is [System.Xml.XmlDeclaration] -and $Body.FirstChild.Encoding) {
                        $encoding = [System.Text.Encoding]::GetEncoding($Body.FirstChild.Encoding)
                    }
                    if ($effectiveContentType) {
                        $mediaType = $null
                        if (-not [System.Net.Http.Headers.MediaTypeHeaderValue]::TryParse($effectiveContentType, [ref]$mediaType) -and -not $SkipHeaderValidation) { throw 'Invalid ContentType. Use SkipHeaderValidation to send an unvalidated content type.' }
                        if ($mediaType -and $mediaType.CharSet) { $encoding = [System.Text.Encoding]::GetEncoding($mediaType.CharSet.Trim('"')) }
                    }
                    $content = New-Object System.Net.Http.ByteArrayContent -ArgumentList (,$encoding.GetBytes($text))
                }
            }
            if ($null -eq $content -and ($currentMethod -in @('POST', 'PUT', 'PATCH') -or $contentHeaders.Count -gt 0 -or $effectiveContentType)) {
                $content = New-Object System.Net.Http.ByteArrayContent -ArgumentList (,[byte[]]@())
            }
            if ($content) {
                try {
                    foreach ($name in $contentHeaders.Keys) {
                        if ($name -ieq 'Content-Length') { continue } # Always calculate the actual transmitted length.
                        if ($SkipHeaderValidation) { [void]$content.Headers.TryAddWithoutValidation($name, [string[]]$contentHeaders[$name]) }
                        else { $content.Headers.Add($name, [string[]]$contentHeaders[$name]) }
                    }
                    if ($effectiveContentType) {
                        [void]$content.Headers.Remove('Content-Type')
                        if ($SkipHeaderValidation) { [void]$content.Headers.TryAddWithoutValidation('Content-Type', $effectiveContentType) }
                        else { $content.Headers.ContentType = [System.Net.Http.Headers.MediaTypeHeaderValue]::Parse($effectiveContentType) }
                    }
                    return $content
                } catch { $content.Dispose(); throw }
            }
        }

        function Initialize-IRM51Json {
            if ('RestMethod51.JsonParser' -as [type]) { return }
            $jsonPath = Join-Path $PSScriptRoot 'lib\Newtonsoft.Json.dll'
            if (-not [System.IO.File]::Exists($jsonPath)) { throw "JSON conversion requires the DLL files supplied in the complete package. Missing: $jsonPath" }
            [void][System.Reflection.Assembly]::LoadFrom($jsonPath)
            $jsonSource = @'
using System;
using System.Collections.Generic;
using System.IO;
using System.Management.Automation;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
namespace RestMethod51 {
    public static class JsonParser {
        // Framework's Double parser loses the sign of -0.0; modern .NET preserves it.
        sealed class NumberReader : JsonTextReader {
            readonly string source;
            readonly List<int> lines = new List<int>();
            public NumberReader(string source) : base(new StringReader(source)) {
                this.source = source; CloseInput = true; lines.Add(0);
                for (int i = 0; i < source.Length; i++) {
                    if (source[i] == '\r') { if (i + 1 < source.Length && source[i + 1] == '\n') i++; lines.Add(i + 1); }
                    else if (source[i] == '\n') lines.Add(i + 1);
                }
            }
            static bool NumberCharacter(char c) { return c >= '0' && c <= '9' || c == '-' || c == '+' || c == '.' || c == 'e' || c == 'E'; }
            public override bool Read() {
                bool success = base.Read();
                if (success && TokenType == JsonToken.Float && Value is double && (double)Value == 0.0) {
                    int end = Math.Min(source.Length, lines[Math.Max(0, LineNumber - 1)] + LinePosition);
                    int start = end;
                    while (start > 0 && NumberCharacter(source[start - 1])) start--;
                    if (start < end && source[start] == '-') SetToken(JsonToken.Float, BitConverter.Int64BitsToDouble(Int64.MinValue), false);
                }
                return success;
            }
        }
        public static object Parse(string text) {
            var settings = new JsonSerializerSettings();
            settings.DateParseHandling = DateParseHandling.DateTime;
            settings.DateTimeZoneHandling = DateTimeZoneHandling.RoundtripKind;
            settings.FloatParseHandling = FloatParseHandling.Double;
            settings.TypeNameHandling = TypeNameHandling.None;
            settings.MetadataPropertyHandling = MetadataPropertyHandling.Ignore;
            settings.MaxDepth = 1024;
            settings.CheckAdditionalContent = true;
            object result;
            using (var reader = new NumberReader(text)) result = JsonSerializer.Create(settings).Deserialize(reader);
            // DeserializeObject also returns null for an empty/comment-only document.
            if (result == null) JToken.Parse(text);
            return ConvertValue(result);
        }
        static object ConvertValue(object input) {
            var obj = input as JObject;
            if (obj != null) {
                var names = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                var output = new PSObject();
                foreach (JProperty property in obj.Properties()) {
                    if (String.IsNullOrEmpty(property.Name) || !names.Add(property.Name))
                        throw new FormatException("JSON contains an empty property name or names that differ only by case.");
                    output.Properties.Add(new PSNoteProperty(property.Name, ConvertValue(property.Value)));
                }
                return output;
            }
            var array = input as JArray;
            if (array != null) {
                var output = new List<object>(array.Count);
                foreach (JToken token in array)
                    if (token.Type != JTokenType.Comment) output.Add(ConvertValue(token));
                return output.ToArray();
            }
            var scalar = input as JValue;
            if (scalar != null) return scalar.Value;
            if (input is JToken) throw new FormatException("Unsupported JSON token.");
            return input;
        }
    }
}
'@
            Add-Type -TypeDefinition $jsonSource -ReferencedAssemblies @($jsonPath, [System.Management.Automation.PSObject].Assembly.Location, 'System', 'System.Core', 'System.Numerics') -ErrorAction Stop
        }

        function ConvertFrom-IRM51Response([string] $Text, [string] $MediaType) {
            # Explicit success flag distinguishes valid JSON null / [] from failed parsing.
            $formats = if ($MediaType -match '(?i)(json|javascript)') { @('json', 'xml') } else { @('xml', 'json') }
            foreach ($format in $formats) {
                if ($format -eq 'json') { Initialize-IRM51Json }
                try {
                    if ($format -eq 'json') {
                        if ([string]::IsNullOrWhiteSpace($Text)) { continue }
                        $value = [RestMethod51.JsonParser]::Parse($Text)
                        return [pscustomobject]@{ Value = $value; Feed = $false }
                    }
                    $settings = New-Object System.Xml.XmlReaderSettings
                    $settings.DtdProcessing = [System.Xml.DtdProcessing]::Ignore
                    $settings.XmlResolver = $null
                    $settings.IgnoreProcessingInstructions = $true
                    $settings.CheckCharacters = $false
                    $settings.MaxCharactersFromEntities = 1024
                    $stringReader = New-Object System.IO.StringReader -ArgumentList (,$Text)
                    $reader = [System.Xml.XmlReader]::Create($stringReader, $settings)
                    try {
                        $document = New-Object System.Xml.XmlDocument
                        $document.XmlResolver = $null
                        $document.PreserveWhitespace = $true
                        $document.Load($reader)
                    } finally { $reader.Dispose(); $stringReader.Dispose() }
                    $nodes = $null
                    if ($document.DocumentElement.LocalName -eq 'rss') { $nodes = $document.SelectNodes('/rss/channel/item') }
                    elseif ($document.DocumentElement.LocalName -eq 'feed' -and $document.DocumentElement.NamespaceURI -eq 'http://www.w3.org/2005/Atom') {
                        $ns = New-Object System.Xml.XmlNamespaceManager -ArgumentList (,$document.NameTable)
                        $ns.AddNamespace('a', 'http://www.w3.org/2005/Atom')
                        $nodes = $document.SelectNodes('/a:feed/a:entry', $ns)
                    }
                    if ($null -ne $nodes) { return [pscustomobject]@{ Value = $nodes; Feed = $true } }
                    return [pscustomobject]@{ Value = $document; Feed = $false }
                } catch { }
            }
            [pscustomobject]@{ Value = $Text; Feed = $false }
        }

        if ($HttpVersion -notin @([version]'1.0', [version]'1.1', [version]'2.0')) { throw 'Supported HTTP versions are 1.0, 1.1 and 2.0; HTTP/3 is unavailable.' }
        if ($PSBoundParameters.ContainsKey('UnixSocket')) { throw 'UnixSocket is unavailable on .NET Framework / PowerShell 5.1.' }
        if ($WebSession -and $SessionVariable) { throw 'WebSession and SessionVariable cannot be combined.' }
        if ($NoProxy -and ($Proxy -or $ProxyCredential -or $ProxyUseDefaultCredentials)) { throw 'NoProxy cannot be combined with proxy parameters.' }
        if (($ProxyCredential -or $ProxyUseDefaultCredentials) -and -not $Proxy) { throw 'ProxyCredential and ProxyUseDefaultCredentials require Proxy.' }
        if ($ProxyCredential -and $ProxyUseDefaultCredentials) { throw 'Specify only one proxy credential option.' }
        if ($UseDefaultCredentials -and ($Credential -or $Authentication -ne 'None')) { throw 'UseDefaultCredentials cannot be combined with Credential or Authentication.' }
        if ($Authentication -eq 'Basic' -and -not $Credential) { throw 'Basic authentication requires Credential.' }
        if ($Authentication -in @('Bearer', 'OAuth') -and -not $Token) { throw 'Bearer/OAuth authentication requires Token.' }
        if ($Token -and $Authentication -notin @('Bearer', 'OAuth')) { throw 'Token requires Authentication Bearer or OAuth.' }
        if ($PassThru -and -not $OutFile) { throw 'PassThru requires OutFile.' }
        if ($Resume -and -not $OutFile) { throw 'Resume requires OutFile.' }
        if ($Certificate -and $CertificateThumbprint) { throw 'Specify Certificate or CertificateThumbprint, not both.' }
        $keepSession = [bool]($WebSession -or $SessionVariable)
        $session = if ($WebSession) { $WebSession } else { New-Object Microsoft.PowerShell.Commands.WebRequestSession }
        $settings = if ($session.PSObject.Properties['RestMethod51Settings']) { $session.RestMethod51Settings } else { @{} }
        foreach ($option in @('NoProxy','SkipCertificateCheck','SslProtocol','ConnectionTimeoutSeconds','OperationTimeoutSeconds','MaximumRetryCount','RetryIntervalSec')) {
            if ($PSBoundParameters.ContainsKey($option)) { $settings[$option] = $PSBoundParameters[$option] }
            elseif ($settings.ContainsKey($option)) { Set-Variable -Name $option -Value $settings[$option] }
        }
        if ($Proxy) { $NoProxy = $false; $settings['NoProxy'] = $false }
        $session | Add-Member -NotePropertyName RestMethod51Settings -NotePropertyValue $settings -Force
        $sslFlags = 0
        foreach ($protocol in $SslProtocol) {
            switch ($protocol) {
                'Default' { }
                # PowerShell 7.6 maps the obsolete Tls/Tls11 names to TLS 1.2.
                'Tls' { $sslFlags = $sslFlags -bor 3072 }
                'Tls11' { $sslFlags = $sslFlags -bor 3072 }
                'Tls12' { $sslFlags = $sslFlags -bor 3072 }
                'Tls13' { $sslFlags = $sslFlags -bor 12288 }
            }
        }
        if (-not $session.Cookies) { $session.Cookies = New-Object System.Net.CookieContainer }
        if ($Credential) { $session.Credentials = $Credential.GetNetworkCredential(); $session.UseDefaultCredentials = $false }
        if ($UseDefaultCredentials) { $session.UseDefaultCredentials = $true }
        if ($Proxy) {
            $webProxy = New-Object System.Net.WebProxy -ArgumentList $Proxy
            if ($ProxyCredential) { $webProxy.Credentials = $ProxyCredential.GetNetworkCredential() }
            elseif ($ProxyUseDefaultCredentials) { $webProxy.UseDefaultCredentials = $true }
            $session.Proxy = $webProxy
        }
        if ($CertificateThumbprint) {
            $Certificate = Get-Item -LiteralPath ('Cert:\CurrentUser\My\' + $CertificateThumbprint) -ErrorAction Stop
        }
        if ($Certificate) {
            if (-not $session.Certificates) { $session.Certificates = New-Object System.Security.Cryptography.X509Certificates.X509CertificateCollection }
            # Keep the original certificate context and its CSP/KSP-backed key association.
            # Repeated calls with the same certificate should retain the existing transport.
            if (-not $session.Certificates.Contains($Certificate)) { [void]$session.Certificates.Add($Certificate) }
        }
        if ($PSBoundParameters.ContainsKey('MaximumRedirection')) { $session.MaximumRedirection = $MaximumRedirection }
        elseif ($session.MaximumRedirection -ge 0) { $MaximumRedirection = $session.MaximumRedirection }
        if ($PSBoundParameters.ContainsKey('UserAgent')) { $session.UserAgent = $UserAgent }
        if ($Headers) {
            foreach ($name in $Headers.Keys) {
                # WebRequestSession.Headers uses string values in Windows PowerShell 5.1.
                $session.Headers[[string]$name] = [string]::Join(', ', [string[]]@($Headers[$name]))
            }
        }
        if ($Authentication -eq 'Basic') {
            $networkCredential = $Credential.GetNetworkCredential()
            $basic = '{0}:{1}' -f $networkCredential.UserName, $networkCredential.Password
            $session.Headers['Authorization'] = 'Basic ' + [Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($basic))
            $basic = $null
        } elseif ($Authentication -in @('Bearer', 'OAuth')) {
            $ptr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($Token)
            try { $session.Headers['Authorization'] = 'Bearer ' + [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr) }
            finally { [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr) }
        }
        if ($SessionVariable) { Set-Variable -Name $SessionVariable -Value $session -Scope 1 }
    }

    process {
        $request = $null
        $response = $null
        $outputStream = $null
        $inputPath = $null
        $httpContentBytes = $null
        $streamBodyBytes = $null
        try {
            $currentUri = $Uri
            if (-not $currentUri.IsAbsoluteUri) { $currentUri = [uri]('http://' + $currentUri.OriginalString) }
            if ($currentUri.Scheme -notin @('http', 'https')) { throw 'This implementation supports only HTTP and HTTPS URIs.' }
            if ($currentUri.UserInfo) { throw 'URI-embedded credentials are not supported. Use Credential or Token.' }
            if (-not $AllowUnencryptedAuthentication -and $currentUri.Scheme -ne 'https' -and ($Credential -or $Token -or $Authentication -ne 'None' -or $session.Credentials -or $session.UseDefaultCredentials)) {
                throw 'Authentication over HTTP requires AllowUnencryptedAuthentication.'
            }
            if ($null -ne $Body -and $Body.GetType().FullName -eq 'Microsoft.PowerShell.Commands.FormObject') { $Body = $Body.Fields }
            $bodySources = [int]($null -ne $Body) + [int]($null -ne $Form) + [int][bool]$InFile
            if ($bodySources -gt 1) { throw 'Body, Form and InFile are mutually exclusive.' }
            if ($InFile) {
                $inputPath = Get-IRM51FullPath $InFile
                if (-not [System.IO.File]::Exists($inputPath)) { throw "InFile does not exist: $inputPath" }
            }
            $outputPath = if ($OutFile) { Get-IRM51FullPath $OutFile } else { $null }
            $outputIsDirectory = $outputPath -and [System.IO.Directory]::Exists($outputPath)
            if ($Resume -and $outputIsDirectory) { throw 'Resume requires an OutFile filename, not a directory.' }
            if ($inputPath -and $outputPath -and $inputPath -eq $outputPath) { throw 'InFile and OutFile must be different files.' }
            $initialMethod = if ($CustomMethod) { $CustomMethod.ToUpperInvariant() } elseif ($Method -eq 'Default') { 'GET' } else { $Method.ToUpperInvariant() }
            if ($Body -is [System.Collections.IDictionary] -and $initialMethod -eq 'GET') {
                $builder = New-Object System.UriBuilder -ArgumentList $currentUri
                $query = ConvertTo-IRM51Query $Body
                $builder.Query = ($builder.Query.TrimStart('?') + '&' + $query).TrimStart('&')
                $currentUri = $builder.Uri
            }
            $contentHeaders = @{}
            $contentHeaderNames = @('Allow','Content-Disposition','Content-Encoding','Content-Language','Content-Length','Content-Location','Content-MD5','Content-Range','Content-Type','Expires','Last-Modified')
            foreach ($name in $session.Headers.Keys) {
                if ($name -in $contentHeaderNames) { $contentHeaders[$name] = $session.Headers[$name] }
            }
            $effectiveContentType = if ($PSBoundParameters.ContainsKey('ContentType')) { $ContentType } elseif ($contentHeaders.ContainsKey('Content-Type')) { $contentHeaders['Content-Type'] } elseif ($initialMethod -eq 'POST') { 'application/x-www-form-urlencoded' } else { $null }
            if ($Body -is [System.Net.Http.HttpContent]) { $httpContentBytes = $Body.ReadAsByteArrayAsync().GetAwaiter().GetResult() }
            elseif ($Body -is [System.IO.Stream]) {
                $bodyBuffer = New-Object System.IO.MemoryStream
                try { [RestMethod51.Internal]::Copy($Body, $bodyBuffer, $OperationTimeoutSeconds); $streamBodyBytes = $bodyBuffer.ToArray() }
                finally { $bodyBuffer.Dispose() }
            }
            $resumeOffset = if ($Resume -and [System.IO.File]::Exists($outputPath)) { (Get-Item -LiteralPath $outputPath).Length } else { 0L }
            $page = 0
            $suppressAuthorization = $false
            $sendCredentials = $true
            do {
                $page++
                $currentMethod = $initialMethod
                $sendBody = $true
                $redirectCount = 0
                $retryCount = 0
                while ($true) {
                    Write-Verbose ("{0} {1}" -f $currentMethod, $currentUri.GetLeftPart([System.UriPartial]::Path))
                    $request = New-Object System.Net.Http.HttpRequestMessage -ArgumentList (New-Object System.Net.Http.HttpMethod -ArgumentList $currentMethod), $currentUri
                    $request.Version = $HttpVersion
                    if ($sendBody) { $request.Content = New-IRM51Content }
                    if ($null -ne $request.Content -and $currentMethod -in @('HEAD','TRACE')) {
                        throw 'A request body or content headers with HEAD or TRACE are unavailable on this transport.'
                    }
                    $useWinHttp = ($currentMethod -eq 'GET' -and $null -ne $request.Content) -or $HttpVersion -eq [version]'2.0' -or ($sslFlags -band 12288) -ne 0
                    $client = Get-IRM51Client $sendCredentials $useWinHttp
                    foreach ($name in $session.Headers.Keys) {
                        if ($name -in $contentHeaderNames) { continue }
                        if ($suppressAuthorization -and $name -ieq 'Authorization') { continue }
                        if ($SkipHeaderValidation) { [void]$request.Headers.TryAddWithoutValidation($name, $session.Headers[$name]) }
                        else { $request.Headers.Add($name, $session.Headers[$name]) }
                    }
                    if (-not $request.Headers.Contains('User-Agent') -and $session.UserAgent) {
                        if ($SkipHeaderValidation) { [void]$request.Headers.TryAddWithoutValidation('User-Agent', $session.UserAgent) }
                        else { $request.Headers.Add('User-Agent', $session.UserAgent) }
                    }
                    if ($DisableKeepAlive) { $request.Headers.ConnectionClose = $true }
                    if ($TransferEncoding) {
                        if ($TransferEncoding -ne 'chunked') { $request.Headers.TransferEncoding.ParseAdd($TransferEncoding) }
                        $request.Headers.TransferEncodingChunked = $true
                    } elseif ($request.Headers.Contains('Transfer-Encoding')) { $request.Headers.TransferEncodingChunked = $true }
                    if ($Resume) { $request.Headers.Range = New-Object System.Net.Http.Headers.RangeHeaderValue -ArgumentList $resumeOffset, $null }
                    $response = [RestMethod51.Internal]::Send($client, $request)
                    $status = [int]$response.StatusCode
                    Write-Verbose ('HTTP/{0} {1}' -f $response.Version, $status)

                    if (($status -eq 304 -or ($status -ge 400 -and $status -le 599)) -and $retryCount -lt $MaximumRetryCount -and -not ($Resume -and $status -eq 416)) {
                        $retryCount++
                        $delay = $RetryIntervalSec
                        if ($status -eq 429 -and $response.Headers.RetryAfter -and $response.Headers.RetryAfter.Delta) {
                            $delay = [math]::Max(0, [math]::Ceiling($response.Headers.RetryAfter.Delta.TotalSeconds))
                        }
                        $response.Dispose(); $response = $null
                        $request.Dispose(); $request = $null
                        Write-Verbose "HTTP $status; retry $retryCount of $MaximumRetryCount in $delay seconds."
                        Start-Sleep -Seconds $delay
                        continue
                    }
                    if ($status -in @(300, 301, 302, 303, 307, 308) -and $response.Headers.Location) {
                        if ($redirectCount -ge $MaximumRedirection) { throw "MaximumRedirection ($MaximumRedirection) exceeded." }
                        $nextUri = New-Object System.Uri -ArgumentList $currentUri, $response.Headers.Location
                        if ($nextUri.Scheme -notin @('http','https') -or $nextUri.UserInfo) { throw 'Unsupported redirect URI.' }
                        if ($currentUri.Scheme -eq 'https' -and $nextUri.Scheme -eq 'http' -and -not $AllowInsecureRedirect) { throw 'HTTPS to HTTP redirection requires AllowInsecureRedirect.' }
                        if (-not $PreserveAuthorizationOnRedirect) { $suppressAuthorization = $true }
                        # Challenge-based credentials are never reapplied automatically after a redirect.
                        $sendCredentials = $false
                        if (-not $PreserveHttpMethodOnRedirect -and (($status -in @(301,302) -and $currentMethod -eq 'POST') -or ($status -eq 303 -and $currentMethod -ne 'HEAD'))) {
                            $currentMethod = 'GET'; $sendBody = $false
                        }
                        $currentUri = $nextUri
                        $redirectCount++
                        $response.Dispose(); $response = $null
                        $request.Dispose(); $request = $null
                        continue
                    }
                    break
                }

                $responseHeaders = New-Object 'System.Collections.Generic.Dictionary[string,string[]]' -ArgumentList ([System.StringComparer]::OrdinalIgnoreCase)
                foreach ($h in $response.Headers) { $responseHeaders[$h.Key] = [string[]]@($h.Value) }
                foreach ($h in $response.Content.Headers) { $responseHeaders[$h.Key] = [string[]]@($h.Value) }
                if ($StatusCodeVariable) { Set-Variable -Name $StatusCodeVariable -Value $status -Scope 1 }
                if ($ResponseHttpVersionVariable) { Set-Variable -Name $ResponseHttpVersionVariable -Value $response.Version -Scope 1 }
                if ($ResponseHeadersVariable) { Set-Variable -Name $ResponseHeadersVariable -Value $responseHeaders -Scope 1 }

                $complete = $false
                $append = $false
                if ($Resume -and $status -eq 416) {
                    $range = $response.Content.Headers.ContentRange
                    if ($range -and $null -ne $range.Length -and $range.Length -eq $resumeOffset) { $complete = $true }
                    elseif ($resumeOffset -gt 0) {
                        # Local file larger than remote: retry once as a full download.
                        $response.Dispose(); $response = $null
                        $request.Dispose(); $request = $null
                        $resumeOffset = 0L
                        $nextPage = $currentUri
                        $page--
                        continue
                    }
                } elseif ($Resume -and $status -eq 206) {
                    $range = $response.Content.Headers.ContentRange
                    if (-not $range -or $range.From -ne $resumeOffset -or $range.Unit -ne 'bytes') { throw 'Invalid Content-Range in resumed response.' }
                    $append = $resumeOffset -gt 0
                }

                $isError = -not $response.IsSuccessStatusCode -and -not $complete
                $writePipeline = -not $OutFile -or $PassThru
                $buffer = if (($writePipeline -or $isError) -and -not $complete) { New-Object System.IO.MemoryStream } else { $null }
                try {
                    if ($OutFile -and -not $complete -and (-not $isError -or $SkipHttpErrorCheck)) {
                        $filePath = $outputPath
                        if ($outputIsDirectory) {
                            $leaf = [uri]::UnescapeDataString(($currentUri.AbsolutePath -split '/')[-1])
                            if (-not $leaf -or $leaf -in @('.', '..') -or $leaf.IndexOfAny([System.IO.Path]::GetInvalidFileNameChars()) -ge 0) { throw 'Cannot derive a safe filename from the final URI. Supply an OutFile filename.' }
                            $filePath = [System.IO.Path]::Combine($outputPath, $leaf)
                        }
                        $mode = if ($append) { [System.IO.FileMode]::Append } else { [System.IO.FileMode]::Create }
                        $outputStream = New-Object System.IO.FileStream -ArgumentList $filePath, $mode, ([System.IO.FileAccess]::Write), ([System.IO.FileShare]::Read)
                    }
                    if (-not $complete) {
                        $stream = $response.Content.ReadAsStreamAsync().GetAwaiter().GetResult()
                        try {
                            if ($buffer) {
                                [RestMethod51.Internal]::Copy($stream, $buffer, $OperationTimeoutSeconds)
                                if ($outputStream) { $buffer.Position = 0; $buffer.CopyTo($outputStream) }
                            } elseif ($outputStream) { [RestMethod51.Internal]::Copy($stream, $outputStream, $OperationTimeoutSeconds) }
                            else { [RestMethod51.Internal]::Copy($stream, [System.IO.Stream]::Null, $OperationTimeoutSeconds) }
                        } finally { $stream.Dispose() }
                    }
                    if ($outputStream) { $outputStream.Dispose(); $outputStream = $null }
                    if ($buffer) {
                        $bytes = $buffer.ToArray()
                        $charset = if ($response.Content.Headers.ContentType) { $response.Content.Headers.ContentType.CharSet } else { $null }
                        $text = [RestMethod51.Internal]::Decode($bytes, $charset)
                        if ($isError -and -not $SkipHttpErrorCheck) {
                            # Preserve readable error content after the network response has been closed.
                            $replacement = New-Object System.Net.Http.ByteArrayContent -ArgumentList (,$bytes)
                            foreach ($h in $response.Content.Headers) { [void]$replacement.Headers.TryAddWithoutValidation($h.Key, [string[]]@($h.Value)) }
                            $response.Content.Dispose()
                            $response.Content = $replacement
                            $exception = New-Object RestMethod51.HttpResponseException -ArgumentList ("Response status code does not indicate success: {0} ({1})." -f $status, $response.ReasonPhrase), $response
                            $errorRecord = New-Object System.Management.Automation.ErrorRecord -ArgumentList $exception, 'WebCmdletWebResponseException', ([System.Management.Automation.ErrorCategory]::InvalidOperation), $currentUri
                            $errorRecord.ErrorDetails = New-Object System.Management.Automation.ErrorDetails -ArgumentList (,$text)
                            $response = $null # Owned by the exception from this point.
                            $PSCmdlet.ThrowTerminatingError($errorRecord)
                        }
                        if ($writePipeline) {
                            $mediaType = if ($response.Content.Headers.ContentType) { $response.Content.Headers.ContentType.MediaType } else { '' }
                            $result = ConvertFrom-IRM51Response $text $mediaType
                            $PSCmdlet.WriteObject($result.Value, [bool]$result.Feed)
                        }
                    }
                } finally {
                    if ($buffer) { $buffer.Dispose() }
                    if ($outputStream) { $outputStream.Dispose(); $outputStream = $null }
                }

                $nextPage = $null
                if ($FollowRelLink -and $page -lt $MaximumFollowRelLink -and $responseHeaders.ContainsKey('Link')) {
                    foreach ($link in $responseHeaders['Link']) {
                        # Split only outside <...> and quoted parameter values; commas are legal in URLs.
                        foreach ($match in [regex]::Matches($link, '<(?<url>[^>]+)>\s*(?<params>(?:[^,"<]|"[^"]*")*)')) {
                            $rel = [regex]::Match($match.Groups['params'].Value, '(?i)(?:^|;)\s*rel\s*=\s*(?:"(?<q>[^"]*)"|(?<u>[^;\s,]+))')
                            $relations = if ($rel.Groups['q'].Success) { $rel.Groups['q'].Value } else { $rel.Groups['u'].Value }
                            if (($relations -split '\s+') -contains 'next') { $nextPage = New-Object System.Uri -ArgumentList $currentUri, $match.Groups['url'].Value; break }
                        }
                        if ($nextPage) { break }
                    }
                }
                $response.Dispose(); $response = $null
                $request.Dispose(); $request = $null
                if ($nextPage) {
                    if ($nextPage.Scheme -notin @('http','https') -or $nextPage.UserInfo) { throw 'Unsupported pagination URI.' }
                    if ($currentUri.Scheme -eq 'https' -and $nextPage.Scheme -eq 'http' -and -not $AllowInsecureRedirect) { throw 'HTTPS to HTTP pagination requires AllowInsecureRedirect.' }
                    if (-not $PreserveAuthorizationOnRedirect) { $suppressAuthorization = $true }
                    $sendCredentials = $false
                    $currentUri = $nextPage
                }
            } while ($nextPage)
        } finally {
            if ($request) { $request.Dispose() }
            if ($response) { $response.Dispose() }
            if ($outputStream) { $outputStream.Dispose() }
            if (-not $keepSession -and $session.PSObject.Properties['RestMethod51Transport']) {
                $session.RestMethod51Transport.Client.Dispose()
                $session.PSObject.Properties.Remove('RestMethod51Transport')
            }
        }
    }
}
