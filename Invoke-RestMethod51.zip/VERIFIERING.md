# Verifiering 2026-11-05

- Windows PowerShell: **5.1.29698.1000**, 64 bitar, Windows-version 10.0.29698.
- .NET Framework: registervärdena **Version = 4.8.10004**, `Release = 534292`.
- Körning: `Test-Invoke-RestMethod51.ps1 -TestTls13 -PowerShell7Path ...`, inklusive automatiskt genererat tillfälligt TLS-certifikat och valfri jämförelse med PowerShell 7.
- Huvudsvit: **78 godkända tester, 0 misslyckade**.
- Protokollsvit: **6 godkända tester, 0 misslyckade**. Totalt **84 godkända tester**.
- HTTP/2-testserver: lokal Kestrel, byggd med .NET 10 SDK och körd med ASP.NET Core 10.0.9. Klienten förblev PowerShell 5.1 / .NET Framework. .NET 10 behövs inte för funktionen.
- Samtliga nätverksanrop i testsviten gick till tillfälliga servrar på `127.0.0.1`.
- Ordinarie parameternamn jämfördes även mot den lokalt installerade 7.6.9-cmdleten; inga saknades. PowerShell 7:s tillkommande common parameter `ProgressAction` ingår inte.
- `ResponseHttpVersionVariable` är ett dokumenterat tillägg till originalets parametrar.

Referens för beteendet är dokumentationen för 7.6 och källkoden vid taggen v7.6.7. Originalcmdleten från exakt 7.6.7 har inte körts sida vid sida. Testresultatet avser den medföljande lokala testsviten, inte Microsofts fullständiga kompatibilitetstestning.

Testade områden: GET/frågeparametrar, POST/PATCH/egna metoder, UTF-8 och XML-kodning, header-validering, JSON-array/null/bool/kommentarer, XML/RSS/Atom, textfallback, svarskodning och gzip, HTTP-fel och felkropp, återförsök, omdirigeringars metoder och Authorization, cookies och sessionåteranvändning, proxy/miljövariabler, Basic/Bearer, spärr mot autentisering över HTTP, paginering, multipart med filer/listor, HttpContent och streams, InFile/OutFile/PassThru/Resume, HTTP/1.0, chunked transfer, tidsgränser, certifikatkontroll samt tillåten/spärrad HTTPS-nedgradering.

Domän-/Windows-autentisering och klientcertifikat mot externa tjänster har inte integrationstestats. Se README.md för alla kända begränsningar.

Uppdateringen för GET med kropp verifierades med de medföljande WinHttpHandler-beroendena. Testerna bekräftar att servern tar emot själva GET-kroppen, inklusive UTF-8-JSON, byte-array, stream och InFile. Även GET-innehållsheaders utan kropp, 307-omdirigering med omsänd kropp och borttagen Authorization, Bearer, cookies och transportbyte i samma session, explicit proxy, HTTP-felsvar, gzip, återförsök, anslutnings-/läsningstidsgränser samt HTTPS med godkänd/avvisad certifikatkontroll ingår.

## Faktisk protokollförhandling

Följande kontrollerades både genom klientens `HttpResponseMessage.Version` och testserverns rapport om anslutningen:

- **HTTP/2.0 över TLS 1.2**.
- **HTTP/2.0 över TLS 1.3 med GET och JSON-kropp**; kroppen kom fram oförändrad.
- **HTTP/2.0 över TLS 1.3 med POST och kropp**.
- HTTP/2-preferens mot en server som bara stöder HTTP/1.1 rapporterade faktiskt HTTP/1.1.
- Uttryckligt val av endast TLS 1.3 misslyckades mot en TLS 1.2-server i stället för att falla tillbaka.
- Servercertifikat kontrollerades normalt även vid HTTP/2 och TLS 1.3.

Huvudsviten verifierade dessutom TLS 1.3 mot en separat server som endast tillåter TLS 1.3. Självsignerade testcertifikat användes med uttryckligt certifikatundantag i positiva testfall och utan undantag i negativa testfall. Ingen tillit installerades.

## JSON-värden och typer

Samma **28 JSON-testfall** skickades till kompatibilitetsfunktionen och den lokalt installerade originalcmdleten i **PowerShell 7.6.9**. Objektstruktur, CLR-typ, skalärvärde, datumets Kind/ticks och flyttalens bitrepresentation jämfördes. Samtliga jämförelser passerade.

Testfallen omfattar Int64-gränser, BigInteger, Double, exponenttal, negativ nolla, UTC/offset/zonlösa datum, datumliknande strängar, Microsoft-datum, nästlade arrayer/objekt, tomma arrayer/objekt, null, bool, rotvärden, metadata som data, dubbla egenskaper, skiftlägeskonflikter, tomma namn, kommentarer, trailing commas, enkla citattecken, icke-finita tal, felaktig JSON och tom text. Parsern använder Json.NET 13.0.4 med de centrala inställningarna från `JsonObject` vid taggen v7.6.7 och en projektion till PowerShell-objekt.

Testerna bevisar inte identiskt beteende för varje JSON-dokument, varje Windows-version eller varje server/proxy. Se README.md för systemkrav och kvarvarande begränsningar.
