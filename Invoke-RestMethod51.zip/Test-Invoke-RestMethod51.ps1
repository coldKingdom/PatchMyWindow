#requires -Version 5.1
param([string] $CertificatePath, [switch] $TestTls13, [string] $PowerShell7Path)
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'Invoke-RestMethod51.ps1')
Add-Type -AssemblyName System.Web.Extensions
if (-not ('RestMethod51Tests.Server' -as [type])) {
    Add-Type -ReferencedAssemblies System, System.Core, System.Web.Extensions -TypeDefinition @'
using System;
using System.IO;
using System.IO.Compression;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Net.Security;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
namespace RestMethod51Tests {
    public sealed class Server : IDisposable {
        TcpListener listener;
        X509Certificate2 certificate;
        int tlsProtocols;
        int retries;
        public string LastError { get; private set; }
        public string BaseUri { get; private set; }
        public Server(string certificatePath) : this(certificatePath, 3072) { }
        public Server(string certificatePath, int tlsProtocols) {
            this.tlsProtocols = tlsProtocols;
            if (!String.IsNullOrEmpty(certificatePath)) certificate = new X509Certificate2(certificatePath, "local-tests");
            listener = new TcpListener(IPAddress.Loopback, 0);
            listener.Start();
            BaseUri = (certificate == null ? "http" : "https") + "://127.0.0.1:" + ((IPEndPoint)listener.LocalEndpoint).Port;
            Task.Run((Action)Run);
        }
        void Run() {
            try { while (true) { var client = listener.AcceptTcpClient(); Task.Run(() => Handle(client)); } }
            catch (SocketException) { } catch (ObjectDisposedException) { }
        }
        string Line(Stream stream) {
            var bytes = new List<byte>();
            for (;;) { int b = stream.ReadByte(); if (b == -1) return null; if (b == 10) return Encoding.ASCII.GetString(bytes.ToArray()).TrimEnd('\r'); bytes.Add((byte)b); }
        }
        byte[] ReadBytes(Stream stream, int count) {
            byte[] result = new byte[count]; int offset = 0;
            while (offset < count) { int n = stream.Read(result, offset, count - offset); if (n == 0) throw new EndOfStreamException(); offset += n; }
            return result;
        }
        void Handle(TcpClient client) {
            try {
                using (client)
                using (var network = client.GetStream()) {
                    Stream stream = network;
                    if (certificate != null) {
                        var ssl = new SslStream(network, false);
                        ssl.AuthenticateAsServer(certificate, false, (SslProtocols)tlsProtocols, false);
                        stream = ssl;
                    }
                    using (stream) {
                        var first = Line(stream); if (first == null) return;
                        var parts = first.Split(' ');
                        string method = parts[0]; var uri = parts[1].StartsWith("http") ? new Uri(parts[1]) : new Uri(BaseUri + parts[1]);
                        var headers = new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase);
                        string line;
                        while (!String.IsNullOrEmpty(line = Line(stream))) { int colon = line.IndexOf(':'); headers[line.Substring(0,colon)] = line.Substring(colon + 1).Trim(); }
                        if (headers.ContainsKey("Expect") && headers["Expect"].Contains("100-continue")) {
                            byte[] interim = Encoding.ASCII.GetBytes("HTTP/1.1 100 Continue\r\n\r\n"); stream.Write(interim,0,interim.Length); stream.Flush();
                        }
                        byte[] body = new byte[0];
                        if (headers.ContainsKey("Transfer-Encoding") && headers["Transfer-Encoding"].Contains("chunked")) {
                            using (var buffer = new MemoryStream()) {
                                for (;;) { int count = Convert.ToInt32(Line(stream).Split(';')[0],16); if (count == 0) { Line(stream); break; } var chunk = ReadBytes(stream,count); buffer.Write(chunk,0,count); Line(stream); }
                                body = buffer.ToArray();
                            }
                        } else if (headers.ContainsKey("Content-Length")) body = ReadBytes(stream,Int32.Parse(headers["Content-Length"]));
                        int status = 200; string contentType = "application/json; charset=utf-8";
                        string extra = ""; int bodyDelay = 0;
                        byte[] data;
                        var serializer = new JavaScriptSerializer();
                        string path = uri.AbsolutePath;
                        string tlsVersion = stream is SslStream ? ((SslStream)stream).SslProtocol.ToString() : "None";
                        string text = serializer.Serialize(new { method = method, query = uri.Query, headers = headers, body = Encoding.UTF8.GetString(body), length = body.Length, tls = tlsVersion });
                        if (path == "/json") text = Encoding.UTF8.GetString(body);
                        if (path == "/array") text = "[1,2,3]";
                        if (path == "/empty-array") text = "[]";
                        if (path == "/null") text = "null";
                        if (path == "/false") text = "false";
                        if (path == "/comments") text = "{/*comment*/\"url\":\"https://example.test/a//b\", //line\n\"n\":2}";
                        if (path == "/xml") { contentType = "application/xml"; text = "<root><value>42</value></root>"; }
                        if (path == "/rss") { contentType = "application/rss+xml"; text = "<rss><channel><item><title>A</title></item><item><title>B</title></item></channel></rss>"; }
                        if (path == "/atom") { contentType = "application/atom+xml"; text = "<feed xmlns=\"http://www.w3.org/2005/Atom\"><entry><title>A</title></entry></feed>"; }
                        if (path == "/text") { contentType = "text/plain"; text = "plain text"; }
                        if (path == "/malformed") text = "{not valid json";
                        if (path.StartsWith("/status/")) { status = Int32.Parse(path.Substring(8)); text = "{\"error\":\"example\"}"; }
                        if (path.StartsWith("/redirect/")) {
                            status = Int32.Parse(path.Substring(10));
                            string target = HttpUtilityParse(uri.Query,"to") ?? "/echo";
                            extra += "Location: " + target + "\r\n";
                        }
                        if (path == "/retry") { int n = Interlocked.Increment(ref retries); if (n <= 2) { status = 429; extra += "Retry-After: 0\r\n"; } text = "{\"attempt\":" + n + "}"; }
                        if (path == "/cookie") extra += "Set-Cookie: sample=value; Path=/\r\n";
                        if (path.StartsWith("/page/")) { int p = Int32.Parse(path.Substring(6)); text = "{\"page\":" + p + "}"; if (p < 3) extra += "Link: </page/" + (p+1) + ">; rel=\"next\", </page/3>; rel=\"last\"\r\n"; }
                        if (path == "/slow-header") Thread.Sleep(1600);
                        if (path == "/slow-body") bodyDelay = 1600;
                        data = Encoding.UTF8.GetBytes(text);
                        if (path == "/latin1") { contentType = "application/json; charset=iso-8859-1"; data = Encoding.GetEncoding(28591).GetBytes("{\"value\":\"\u00e5\u00e4\u00f6\"}"); }
                        if (path == "/bytes" || path == "/range" || path == "/no-range") {
                            contentType = "application/octet-stream"; data = new byte[256]; for(int i=0;i<256;i++) data[i]=(byte)i;
                            if (path == "/range" && headers.ContainsKey("Range")) {
                                int start = Int32.Parse(headers["Range"].Substring(6).TrimEnd('-'));
                                if (start >= data.Length) { status=416; extra += "Content-Range: bytes */256\r\n"; data=new byte[0]; }
                                else { status=206; extra += "Content-Range: bytes " + start + "-255/256\r\n"; var subset = new byte[256-start]; Array.Copy(data,start,subset,0,subset.Length); data=subset; }
                            }
                        }
                        if (path == "/gzip") { using(var compressed=new MemoryStream()) { using(var gzip=new GZipStream(compressed,CompressionMode.Compress,true)) gzip.Write(data,0,data.Length); data=compressed.ToArray(); } extra += "Content-Encoding: gzip\r\n"; }
                        if (status == 204 || method == "HEAD") data = new byte[0];
                        byte[] head = Encoding.ASCII.GetBytes("HTTP/1.1 " + status + " Test\r\nContent-Type: " + contentType + "\r\nContent-Length: " + data.Length + "\r\nConnection: close\r\n" + extra + "\r\n");
                        stream.Write(head,0,head.Length); stream.Flush();
                        if (bodyDelay > 0) Thread.Sleep(bodyDelay);
                        stream.Write(data,0,data.Length); stream.Flush();
                    }
                }
            } catch (Exception e) { LastError = e.ToString(); }
        }
        string HttpUtilityParse(string query, string name) {
            foreach(var entry in query.TrimStart('?').Split('&')) { var p=entry.Split(new char[]{'='},2); if(p[0]==name && p.Length==2) return Uri.UnescapeDataString(p[1]); } return null;
        }
        public void Dispose() { listener.Stop(); if(certificate!=null) certificate.Dispose(); }
    }
}
'@
}

$script:passed = 0
$script:failed = 0
$script:results = New-Object 'System.Collections.Generic.List[object]'
function Assert($Condition, [string]$Message = 'Assertion failed') { if (-not $Condition) { throw $Message } }
function Expect-Error([scriptblock] $Action, [string] $Pattern) {
    $caught = $null
    try { & $Action | Out-Null } catch { $caught = $_ }
    Assert ($null -ne $caught) 'Expected an error, but the operation succeeded.'
    if ($Pattern) { Assert ($caught.ToString() -match $Pattern) ("Unexpected error: " + $caught) }
}
function Test([string] $Name, [scriptblock] $Action) {
    try { & $Action; $script:passed++; Write-Host "PASS $Name"; $script:results.Add([pscustomobject]@{ Test=$Name; Result='PASS'; Detail='' }) }
    catch { $script:failed++; Write-Host "FAIL $Name : $_"; Write-Host $_.ScriptStackTrace; $script:results.Add([pscustomobject]@{ Test=$Name; Result='FAIL'; Detail=$_.ToString() }) }
}
$server = New-Object RestMethod51Tests.Server -ArgumentList (,[string]::Empty)
$base = $server.BaseUri
$temp = Join-Path ([System.IO.Path]::GetTempPath()) ([guid]::NewGuid().ToString())
[void][System.IO.Directory]::CreateDirectory($temp)
$transportSessions = New-Object 'System.Collections.Generic.List[object]'
try {
    if (-not $CertificatePath) {
        # Generate an in-memory self-signed fixture; no Windows certificate store is changed.
        $testKey = New-Object System.Security.Cryptography.RSACng -ArgumentList 2048
        $testCertificate = $null
        try {
            $certificateRequest = New-Object System.Security.Cryptography.X509Certificates.CertificateRequest -ArgumentList 'CN=localhost', $testKey, ([System.Security.Cryptography.HashAlgorithmName]::SHA256), ([System.Security.Cryptography.RSASignaturePadding]::Pkcs1)
            $testCertificate = $certificateRequest.CreateSelfSigned([DateTimeOffset]::UtcNow.AddMinutes(-5), [DateTimeOffset]::UtcNow.AddDays(1))
            $CertificatePath = Join-Path $temp 'local-tests.pfx'
            [System.IO.File]::WriteAllBytes($CertificatePath, $testCertificate.Export([System.Security.Cryptography.X509Certificates.X509ContentType]::Pfx, 'local-tests'))
        } finally { if ($testCertificate) { $testCertificate.Dispose() }; $testKey.Dispose() }
    }
    Test 'GET JSON and response variables in caller scope' {
        $r = Invoke-RestMethod51 "$base/echo" -NoProxy -StatusCodeVariable code -ResponseHeadersVariable rh
        Assert ($r.method -eq 'GET' -and $code -eq 200 -and $rh['content-type'][0] -match 'json')
    }
    Test 'GET dictionary query and URI fragment' {
        $r = Invoke-RestMethod51 "$base/echo?existing=1#fragment" -NoProxy -Body @{ q='a b&c'; number=2 }
        Assert ($r.query -match 'q=a\+b%26c' -and $r.query -match 'existing=1' -and $r.length -eq 0)
    }
    Test 'GET content headers without body' {
        $r=Invoke-RestMethod51 "$base/echo" -NoProxy -ContentType application/json
        Assert ($r.method -eq 'GET' -and $r.length -eq 0 -and $r.headers.'Content-Type' -eq 'application/json')
    }
    Test 'GET JSON body transmitted as UTF-8' {
        $json='{"q":"' + [char]0xe5 + '"}'
        $r=Invoke-RestMethod51 "$base/echo" -NoProxy -Method Get -ContentType 'application/json; charset=utf-8' -Body $json
        Assert ($r.method -eq 'GET' -and $r.body -eq $json -and $r.length -eq [System.Text.Encoding]::UTF8.GetByteCount($json))
    }
    Test 'GET binary body' { $r=Invoke-RestMethod51 "$base/echo" -NoProxy -Body ([byte[]]@(65,66)); Assert ($r.method -eq 'GET' -and $r.body -eq 'AB') }
    Test 'GET stream body' {
        $stream=New-Object System.IO.MemoryStream -ArgumentList (,[System.Text.Encoding]::UTF8.GetBytes('get stream'))
        try { $r=Invoke-RestMethod51 "$base/echo" -NoProxy -Body $stream; Assert ($r.method -eq 'GET' -and $r.body -eq 'get stream' -and $stream.CanRead) }
        finally { $stream.Dispose() }
    }
    Test 'GET InFile body' {
        $file=Join-Path $temp 'get.txt'; [System.IO.File]::WriteAllText($file,'get file')
        $r=Invoke-RestMethod51 "$base/echo" -NoProxy -Method Get -InFile $file
        Assert ($r.method -eq 'GET' -and $r.body -eq 'get file')
    }
    Test 'GET 307 replays body and strips Authorization' {
        $r=Invoke-RestMethod51 "$base/redirect/307" -NoProxy -Body 'get body' -Headers @{Authorization='Bearer sample'}
        Assert ($r.method -eq 'GET' -and $r.body -eq 'get body' -and -not $r.headers.Authorization)
    }
    Test 'GET body Bearer authentication' {
        $r=Invoke-RestMethod51 "$base/echo" -NoProxy -Body 'authenticated' -Authentication Bearer -Token (ConvertTo-SecureString 'sample' -AsPlainText -Force) -AllowUnencryptedAuthentication
        Assert ($r.method -eq 'GET' -and $r.body -eq 'authenticated' -and $r.headers.Authorization -eq 'Bearer sample')
    }
    Test 'GET body session cookies and reuse across transports' {
        $null=Invoke-RestMethod51 "$base/cookie" -NoProxy -SessionVariable s
        $transportSessions.Add($s)
        $r=Invoke-RestMethod51 "$base/echo" -WebSession $s -Body 'get cookie'
        Assert ($r.body -eq 'get cookie' -and $r.headers.Cookie -match 'sample=value')
        $client=$s.RestMethod51Transport.Client
        $r=Invoke-RestMethod51 "$base/echo" -WebSession $s -Body 'again'
        Assert ($r.body -eq 'again' -and [object]::ReferenceEquals($client,$s.RestMethod51Transport.Client))
        $r=Invoke-RestMethod51 "$base/echo" -WebSession $s
        Assert ($r.headers.Cookie -match 'sample=value')
    }
    Test 'GET body explicit proxy' {
        $r=Invoke-RestMethod51 'http://target.invalid/echo' -Proxy $base -Body 'get proxy'
        Assert ($r.method -eq 'GET' -and $r.body -eq 'get proxy')
    }
    Test 'GET body error response and decompression' {
        $r=Invoke-RestMethod51 "$base/status/400" -NoProxy -Body 'error' -SkipHttpErrorCheck -StatusCodeVariable code
        Assert ($code -eq 400 -and $r.error -eq 'example')
        $r=Invoke-RestMethod51 "$base/gzip" -NoProxy -Body 'compressed response'
        Assert ($r.method -eq 'GET' -and $r.body -eq 'compressed response')
    }
    Test 'GET body retries' {
        $retryServer=New-Object RestMethod51Tests.Server -ArgumentList (,[string]::Empty)
        try { $r=Invoke-RestMethod51 ($retryServer.BaseUri+'/retry') -NoProxy -Body 'retry body' -MaximumRetryCount 2; Assert ($r.attempt -eq 3) }
        finally { $retryServer.Dispose() }
    }
    Test 'GET body connection and read timeouts' {
        Expect-Error { Invoke-RestMethod51 "$base/slow-header" -NoProxy -Body 'timeout' -ConnectionTimeoutSeconds 1 }
        Expect-Error { Invoke-RestMethod51 "$base/slow-body" -NoProxy -Body 'timeout' -OperationTimeoutSeconds 1 } 'OperationTimeoutSeconds'
    }
    Test 'POST dictionary form encoding' {
        $r = Invoke-RestMethod51 "$base/echo" -NoProxy -Method Post -Body @{ q='a b&c' }
        Assert ($r.body -eq 'q=a+b%26c' -and $r.headers.'Content-Type' -eq 'application/x-www-form-urlencoded')
    }
    Test 'UTF-8 JSON request' {
        $body = '{"value":"' + [char]0xe5 + '"}'
        $r = Invoke-RestMethod51 "$base/echo" -NoProxy -Method Post -ContentType application/json -Body $body
        Assert ($r.body -eq $body -and $r.length -eq ([System.Text.Encoding]::UTF8.GetByteCount($body)))
    }
    Test 'XML declaration controls request encoding' {
        [xml]$xml='<?xml version="1.0" encoding="utf-16"?><root>value</root>'
        $r=Invoke-RestMethod51 "$base/echo" -NoProxy -Method Post -Body $xml -ContentType application/xml
        Assert ($r.length -eq [System.Text.Encoding]::Unicode.GetByteCount($xml.OuterXml))
    }
    Test 'Custom method' { Assert ((Invoke-RestMethod51 "$base/echo" -NoProxy -CustomMethod PROPFIND).method -eq 'PROPFIND') }
    Test 'Header validation and SkipHeaderValidation' {
        Expect-Error { Invoke-RestMethod51 "$base/echo" -NoProxy -Headers @{ 'If-Match'='unquoted' } }
        $r=Invoke-RestMethod51 "$base/echo" -NoProxy -Headers @{ 'If-Match'='unquoted' } -SkipHeaderValidation
        Assert ($r.headers.'If-Match' -eq 'unquoted')
        $r=Invoke-RestMethod51 "$base/echo" -NoProxy -Method Post -ContentType 'invalid content type' -SkipHeaderValidation -Body 'x'
        Assert ($r.headers.'Content-Type' -eq 'invalid content type')
    }
    Test 'PATCH and binary body' {
        $r = Invoke-RestMethod51 "$base/echo" -NoProxy -Method Patch -Body ([byte[]]@(65,66))
        Assert ($r.method -eq 'PATCH' -and $r.body -eq 'AB')
    }
    Test 'JSON array remains one pipeline object' {
        $count = 0
        Invoke-RestMethod51 "$base/array" -NoProxy | ForEach-Object { $count++; Assert ($_ -is [array] -and $_.Count -eq 3) }
        Assert ($count -eq 1)
    }
    Test 'Empty JSON array remains an empty array' {
        $r = Invoke-RestMethod51 "$base/empty-array" -NoProxy
        Assert ($r -is [array] -and $r.Count -eq 0)
    }
    Test 'JSON null and false' { Assert ($null -eq (Invoke-RestMethod51 "$base/null" -NoProxy)); Assert ((Invoke-RestMethod51 "$base/false" -NoProxy) -eq $false) }
    Test 'JSON comments preserve URL string' { $r=Invoke-RestMethod51 "$base/comments" -NoProxy; Assert ($r.n -eq 2 -and $r.url -eq 'https://example.test/a//b') }
    Test 'JSON numeric types match PowerShell 7' {
        $r=Invoke-RestMethod51 "$base/json" -NoProxy -Method Post -ContentType application/json -Body '{"small":1,"real":1.25,"huge":9223372036854775808}'
        Assert ($r.small -is [long] -and $r.real -is [double] -and $r.huge -is [System.Numerics.BigInteger])
        Assert ($r.huge.ToString() -eq '9223372036854775808')
    }
    Test 'JSON dates match PowerShell 7 default date handling' {
        $r=Invoke-RestMethod51 "$base/json" -NoProxy -Method Post -ContentType application/json -Body '{"utc":"2020-01-01T00:00:00Z","unspecified":"2020-01-01T00:00:00","dateOnly":"2020-01-01"}'
        Assert ($r.utc -is [datetime] -and $r.utc.Kind -eq [DateTimeKind]::Utc)
        Assert ($r.unspecified -is [datetime] -and $r.unspecified.Kind -eq [DateTimeKind]::Unspecified -and $r.dateOnly -is [string])
    }
    Test 'JSON nested arrays preserve scalar types and empty arrays' {
        $r=Invoke-RestMethod51 "$base/json" -NoProxy -Method Post -ContentType application/json -Body '{"items":[1,1.25,null,[],{"date":"2020-01-01T00:00:00Z"}]}'
        Assert ($r.items[0] -is [long] -and $r.items[1] -is [double] -and $null -eq $r.items[2] -and $r.items[3] -is [array] -and $r.items[3].Count -eq 0 -and $r.items[4].date -is [datetime])
    }
    Test 'JSON metadata remains data and exact duplicate names use last value' {
        $r=Invoke-RestMethod51 "$base/json" -NoProxy -Method Post -ContentType application/json -Body '{"$type":"System.IO.FileInfo, mscorlib","$id":"one","n":1,"n":2}'
        Assert ($r.'$type' -eq 'System.IO.FileInfo, mscorlib' -and $r.'$id' -eq 'one' -and $r.n -eq 2)
    }
    Test 'JSON empty and case-conflicting property names fall back to text' {
        foreach ($json in @('{"":1}', '{"a":1,"A":2}')) {
            $r=Invoke-RestMethod51 "$base/json" -NoProxy -Method Post -ContentType application/json -Body $json
            Assert ($r -is [string] -and $r -eq $json)
        }
    }
    Test 'JSON trailing commas and comment-only null' {
        $r=Invoke-RestMethod51 "$base/json" -NoProxy -Method Post -ContentType application/json -Body '{"n":1,}'
        Assert ($r.n -is [long] -and $r.n -eq 1)
        $r=Invoke-RestMethod51 "$base/json" -NoProxy -Method Post -ContentType application/json -Body '/* comment only */'
        Assert ($null -eq $r)
    }
    if ($PowerShell7Path) {
        Test 'JSON values and CLR types agree with native PowerShell 7 on 28 cases' {
            $referenceScript=Join-Path $PSScriptRoot 'tests\Json-Conformance.ps1'
            $referenceFile=Join-Path $temp 'reference.json'; $compatibilityFile=Join-Path $temp 'compatibility.json'
            & $PowerShell7Path -NoProfile -ExecutionPolicy Bypass -File $referenceScript -Uri "$base/json" -OutputPath $referenceFile
            Assert ($LASTEXITCODE -eq 0) 'Native PowerShell JSON reference failed.'
            & $referenceScript -Compatibility -Uri "$base/json" -OutputPath $compatibilityFile
            $expected=Get-Content -Raw -LiteralPath $referenceFile | ConvertFrom-Json
            $actual=Get-Content -Raw -LiteralPath $compatibilityFile | ConvertFrom-Json
            foreach ($record in $expected) {
                $match=$actual | Where-Object { $_.Name -eq $record.Name }
                Assert ($match.Signature -ceq $record.Signature) ("JSON mismatch for {0}: expected {1}; actual {2}" -f $record.Name,$record.Signature,$match.Signature)
            }
        }
    }
    Test 'XML response' { $r=Invoke-RestMethod51 "$base/xml" -NoProxy; Assert ($r -is [xml] -and $r.root.value -eq '42') }
    Test 'RSS entries enumerate' { $r=@(Invoke-RestMethod51 "$base/rss" -NoProxy); Assert ($r.Count -eq 2 -and $r[0].title -eq 'A') }
    Test 'Atom entries' { $r=Invoke-RestMethod51 "$base/atom" -NoProxy; Assert ($r.title.InnerText -eq 'A' -or $r.title -eq 'A') }
    Test 'Plain text and malformed JSON fallback' { Assert ((Invoke-RestMethod51 "$base/text" -NoProxy) -eq 'plain text'); Assert ((Invoke-RestMethod51 "$base/malformed" -NoProxy) -eq '{not valid json') }
    Test 'Response charset' { $r=Invoke-RestMethod51 "$base/latin1" -NoProxy; Assert ($r.value -eq (-join @([char]0xe5,[char]0xe4,[char]0xf6))) }
    Test 'Gzip decompression' { Assert ((Invoke-RestMethod51 "$base/gzip" -NoProxy).method -eq 'GET') }
    Test 'HTTP error carries status and body' {
        try { Invoke-RestMethod51 "$base/status/400" -NoProxy; throw 'Missing HTTP error' }
        catch { Assert ($_.Exception.Response.StatusCode -eq 400 -and $_.ErrorDetails.Message -match 'example'); Assert ($_.Exception.Response.Content.ReadAsStringAsync().GetAwaiter().GetResult() -match 'example') }
    }
    Test 'SkipHttpErrorCheck deserializes error body' { $r=Invoke-RestMethod51 "$base/status/404" -NoProxy -SkipHttpErrorCheck -StatusCodeVariable code; Assert ($code -eq 404 -and $r.error -eq 'example') }
    Test '429 retry with Retry-After' { $r=Invoke-RestMethod51 "$base/retry" -NoProxy -MaximumRetryCount 2; Assert ($r.attempt -eq 3) }
    Test 'Default redirect strips Authorization' { $r=Invoke-RestMethod51 "$base/redirect/302" -NoProxy -Headers @{Authorization='Bearer example'}; Assert (-not $r.headers.Authorization) }
    Test 'PreserveAuthorizationOnRedirect' { $r=Invoke-RestMethod51 "$base/redirect/302" -NoProxy -Headers @{Authorization='Bearer example'} -PreserveAuthorizationOnRedirect; Assert ($r.headers.Authorization -eq 'Bearer example') }
    Test 'POST 302 becomes GET without body' { $r=Invoke-RestMethod51 "$base/redirect/302" -NoProxy -Method Post -Body 'abc'; Assert ($r.method -eq 'GET' -and $r.length -eq 0) }
    Test 'POST 307 preserves body' { $r=Invoke-RestMethod51 "$base/redirect/307" -NoProxy -Method Post -Body 'abc'; Assert ($r.method -eq 'POST' -and $r.body -eq 'abc') }
    Test 'PreserveHttpMethodOnRedirect' { $r=Invoke-RestMethod51 "$base/redirect/302" -NoProxy -Method Post -Body 'abc' -PreserveHttpMethodOnRedirect; Assert ($r.method -eq 'POST' -and $r.body -eq 'abc') }
    Test 'MaximumRedirection enforcement' { Expect-Error { Invoke-RestMethod51 "$base/redirect/302" -NoProxy -MaximumRedirection 0 } 'MaximumRedirection' }
    Test 'Cookie session' {
        $null=Invoke-RestMethod51 "$base/cookie" -NoProxy -SessionVariable s
        $transportSessions.Add($s)
        $firstClient=$s.RestMethod51Transport.Client
        $r=Invoke-RestMethod51 "$base/echo" -NoProxy -WebSession $s
        Assert ($r.headers.Cookie -match 'sample=value' -and [object]::ReferenceEquals($firstClient,$s.RestMethod51Transport.Client))
    }
    Test 'Persistent session retains NoProxy' {
        $null=Invoke-RestMethod51 "$base/echo" -NoProxy -SessionVariable s
        $transportSessions.Add($s)
        $firstClient=$s.RestMethod51Transport.Client
        $null=Invoke-RestMethod51 "$base/echo" -WebSession $s
        Assert ([object]::ReferenceEquals($firstClient,$s.RestMethod51Transport.Client))
    }
    Test 'Explicit HTTP proxy' {
        $r=Invoke-RestMethod51 'http://target.invalid/echo' -Proxy $base
        Assert ($r.method -eq 'GET')
    }
    Test 'Proxy environment variables and NO_PROXY' {
        $oldHttp=$env:HTTP_PROXY; $oldHttps=$env:HTTPS_PROXY; $oldAll=$env:ALL_PROXY; $oldNo=$env:NO_PROXY
        try {
            $env:HTTP_PROXY=$base; $env:HTTPS_PROXY=$null; $env:ALL_PROXY=$null; $env:NO_PROXY=$null
            Assert ((Invoke-RestMethod51 'http://target.invalid/echo').method -eq 'GET')
            $env:HTTP_PROXY='http://127.0.0.1:1'; $env:NO_PROXY='127.0.0.1'
            Assert ((Invoke-RestMethod51 "$base/echo").method -eq 'GET')
            $env:NO_PROXY=$null
            Assert ((Invoke-RestMethod51 "$base/echo" -NoProxy).method -eq 'GET')
        } finally { $env:HTTP_PROXY=$oldHttp; $env:HTTPS_PROXY=$oldHttps; $env:ALL_PROXY=$oldAll; $env:NO_PROXY=$oldNo }
    }
    Test 'Basic authentication' {
        $cred=New-Object pscredential -ArgumentList 'user',(ConvertTo-SecureString 'pass' -AsPlainText -Force)
        $r=Invoke-RestMethod51 "$base/echo" -NoProxy -Authentication Basic -Credential $cred -AllowUnencryptedAuthentication
        Assert ($r.headers.Authorization -eq 'Basic dXNlcjpwYXNz')
    }
    Test 'Bearer token' { $r=Invoke-RestMethod51 "$base/echo" -NoProxy -Authentication Bearer -Token (ConvertTo-SecureString 'test-token' -AsPlainText -Force) -AllowUnencryptedAuthentication; Assert ($r.headers.Authorization -eq 'Bearer test-token') }
    Test 'HTTP authentication guard' { Expect-Error { Invoke-RestMethod51 "$base/echo" -NoProxy -Authentication Bearer -Token (ConvertTo-SecureString 'x' -AsPlainText -Force) } 'AllowUnencryptedAuthentication' }
    Test 'Pagination and page limit' {
        $r=@(Invoke-RestMethod51 "$base/page/1" -NoProxy -FollowRelLink); Assert ($r.Count -eq 3 -and $r[2].page -eq 3)
        $r=@(Invoke-RestMethod51 "$base/page/1" -NoProxy -FollowRelLink -MaximumFollowRelLink 1); Assert ($r.Count -eq 1)
    }
    Test 'Multipart fields, collections and file' {
        $file=Join-Path $temp 'sample.txt'; [System.IO.File]::WriteAllText($file,'FILE-CONTENT')
        $r=Invoke-RestMethod51 "$base/echo" -NoProxy -Method Post -Form @{ title='hello'; tag=@('one','two'); upload=(Get-Item -LiteralPath $file) }
        Assert ($r.headers.'Content-Type' -match 'multipart/form-data' -and $r.body -match 'FILE-CONTENT' -and $r.body -match 'hello' -and $r.body -match 'two')
    }
    Test 'Caller-owned HttpContent remains reusable' {
        $content=New-Object System.Net.Http.StringContent -ArgumentList 'hello'
        try { $r=Invoke-RestMethod51 "$base/redirect/307" -NoProxy -Method Post -Body $content; Assert ($r.body -eq 'hello'); Assert ($content.ReadAsStringAsync().GetAwaiter().GetResult() -eq 'hello') } finally { $content.Dispose() }
    }
    Test 'InFile upload' { $file=Join-Path $temp 'in.txt'; [System.IO.File]::WriteAllText($file,'upload'); $r=Invoke-RestMethod51 "$base/echo" -NoProxy -Method Put -InFile $file; Assert ($r.body -eq 'upload') }
    Test 'Stream body and replay on redirect' {
        $stream=New-Object System.IO.MemoryStream -ArgumentList (,[System.Text.Encoding]::UTF8.GetBytes('stream body'))
        try { $r=Invoke-RestMethod51 "$base/redirect/307" -NoProxy -Method Post -Body $stream; Assert ($r.body -eq 'stream body' -and $stream.CanRead) }
        finally { $stream.Dispose() }
    }
    Test 'OutFile binary download' { $file=Join-Path $temp 'out.bin'; $r=Invoke-RestMethod51 "$base/bytes" -NoProxy -OutFile $file; $b=[System.IO.File]::ReadAllBytes($file); Assert ($null -eq $r -and $b.Length -eq 256 -and $b[255] -eq 255) }
    Test 'OutFile with PassThru' { $file=Join-Path $temp 'out.json'; $r=Invoke-RestMethod51 "$base/echo" -NoProxy -OutFile $file -PassThru; Assert ($r.method -eq 'GET' -and (Get-Item -LiteralPath $file).Length -gt 0) }
    Test 'OutFile directory selects URI filename' { $null=Invoke-RestMethod51 "$base/bytes" -NoProxy -OutFile $temp; Assert ([System.IO.File]::Exists((Join-Path $temp 'bytes'))) }
    Test 'Resume partial, complete, oversized and unsupported range' {
        $file=Join-Path $temp 'resume.bin'; [System.IO.File]::WriteAllBytes($file,[byte[]](0..9))
        $null=Invoke-RestMethod51 "$base/range" -NoProxy -Resume -OutFile $file
        Assert ((Get-Item -LiteralPath $file).Length -eq 256)
        $hash=(Get-FileHash -LiteralPath $file).Hash
        $null=Invoke-RestMethod51 "$base/range" -NoProxy -Resume -OutFile $file
        Assert ((Get-FileHash -LiteralPath $file).Hash -eq $hash)
        [System.IO.File]::WriteAllBytes($file,(New-Object byte[] 300))
        $null=Invoke-RestMethod51 "$base/range" -NoProxy -Resume -OutFile $file
        Assert ((Get-FileHash -LiteralPath $file).Hash -eq $hash)
        [System.IO.File]::WriteAllBytes($file,[byte[]](0..9))
        $null=Invoke-RestMethod51 "$base/no-range" -NoProxy -Resume -OutFile $file
        Assert ((Get-FileHash -LiteralPath $file).Hash -eq $hash)
    }
    Test 'Error does not overwrite OutFile' { $file=Join-Path $temp 'keep.txt'; [System.IO.File]::WriteAllText($file,'keep'); Expect-Error { Invoke-RestMethod51 "$base/status/500" -NoProxy -OutFile $file }; Assert ([System.IO.File]::ReadAllText($file) -eq 'keep') }
    Test 'Pipeline body' { $r='pipeline' | Invoke-RestMethod51 "$base/echo" -NoProxy -Method Post; Assert ($r.body -eq 'pipeline') }
    Test 'HTTP/1.0 request' { Assert ((Invoke-RestMethod51 "$base/echo" -NoProxy -HttpVersion 1.0).method -eq 'GET') }
    Test 'HTTP/2 preference can fall back and exposes actual response version' {
        $r=Invoke-RestMethod51 "$base/echo" -NoProxy -HttpVersion '2.0' -ResponseHttpVersionVariable actualVersion
        Assert ($r.method -eq 'GET' -and $actualVersion -eq [version]'1.1')
    }
    Test 'Chunked transfer' { $r=Invoke-RestMethod51 "$base/echo" -NoProxy -Method Post -Body 'chunk body' -TransferEncoding chunked; Assert ($r.body -eq 'chunk body') }
    Test 'Connection/header timeout' { Expect-Error { Invoke-RestMethod51 "$base/slow-header" -NoProxy -ConnectionTimeoutSeconds 1 } }
    Test 'Response read timeout' { Expect-Error { Invoke-RestMethod51 "$base/slow-body" -NoProxy -OperationTimeoutSeconds 1 } 'OperationTimeoutSeconds' }
    Test 'Unsupported runtime features fail explicitly' {
        Expect-Error { Invoke-RestMethod51 "$base/echo" -NoProxy -HttpVersion 3.0 } 'HTTP/3'
        Expect-Error { Invoke-RestMethod51 "$base/echo" -NoProxy -UnixSocket 'example' } 'UnixSocket'
    }
    if ($CertificatePath) {
        $tls=New-Object RestMethod51Tests.Server -ArgumentList $CertificatePath
        try {
            Test 'Untrusted TLS certificate rejected by default' { Expect-Error { Invoke-RestMethod51 ($tls.BaseUri+'/echo') -NoProxy -ConnectionTimeoutSeconds 5 } }
            Test 'SkipCertificateCheck is request-local' {
                $before=[System.Net.ServicePointManager]::ServerCertificateValidationCallback
                $r=Invoke-RestMethod51 ($tls.BaseUri+'/echo') -NoProxy -SkipCertificateCheck -SslProtocol Tls12
                Assert ($r.method -eq 'GET' -and [object]::ReferenceEquals($before,[System.Net.ServicePointManager]::ServerCertificateValidationCallback))
            }
            Test 'HTTPS GET body and request-local certificate override' {
                $before=[System.Net.ServicePointManager]::ServerCertificateValidationCallback
                $r=Invoke-RestMethod51 ($tls.BaseUri+'/echo') -NoProxy -SkipCertificateCheck -SslProtocol Tls12 -Body '{"get":true}' -ContentType application/json
                Assert ($r.method -eq 'GET' -and $r.body -eq '{"get":true}' -and [object]::ReferenceEquals($before,[System.Net.ServicePointManager]::ServerCertificateValidationCallback))
            }
            Test 'HTTPS GET body rejects untrusted certificate by default' { Expect-Error { Invoke-RestMethod51 ($tls.BaseUri+'/echo') -NoProxy -Body 'untrusted' -ConnectionTimeoutSeconds 5 } }
            Test 'Explicit TLS 1.3 never silently falls back to TLS 1.2' { Expect-Error { Invoke-RestMethod51 ($tls.BaseUri+'/echo') -NoProxy -SkipCertificateCheck -SslProtocol Tls13 -ConnectionTimeoutSeconds 3 } }
            Test 'HTTPS downgrade blocked by default' { Expect-Error { Invoke-RestMethod51 ($tls.BaseUri+'/redirect/302?to='+[uri]::EscapeDataString($base+'/echo')) -NoProxy -SkipCertificateCheck } 'AllowInsecureRedirect' }
            Test 'Explicit HTTPS downgrade permitted' { $r=Invoke-RestMethod51 ($tls.BaseUri+'/redirect/302?to='+[uri]::EscapeDataString($base+'/echo')) -NoProxy -SkipCertificateCheck -AllowInsecureRedirect; Assert ($r.method -eq 'GET') }
        } finally { $tls.Dispose() }
        if ($TestTls13) {
            $tls13=New-Object RestMethod51Tests.Server -ArgumentList $CertificatePath, 12288
            try {
                Test 'TLS 1.3-only server confirms negotiated TLS 1.3' {
                    $r=Invoke-RestMethod51 ($tls13.BaseUri+'/echo') -NoProxy -SkipCertificateCheck -SslProtocol Tls13 -ConnectionTimeoutSeconds 5
                    Assert ($r.tls -eq 'Tls13')
                }
            } finally { $tls13.Dispose() }
        }
    }
} finally {
    foreach ($s in $transportSessions) { if ($s.RestMethod51Transport) { $s.RestMethod51Transport.Client.Dispose() } }
    $server.Dispose()
    # This unique directory is created by this test and contains only its disposable fixtures.
    if ([System.IO.Path]::GetFullPath($temp).StartsWith([System.IO.Path]::GetFullPath([System.IO.Path]::GetTempPath()), [System.StringComparison]::OrdinalIgnoreCase)) { Remove-Item -LiteralPath $temp -Recurse -Force }
}
Write-Host ("Results: {0} passed, {1} failed; PowerShell {2}" -f $script:passed,$script:failed,$PSVersionTable.PSVersion)
if ($script:failed) { exit 1 }
