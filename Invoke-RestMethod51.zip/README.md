# Invoke-RestMethod51

En fristående kompatibilitetsfunktion för **Windows PowerShell 5.1 med .NET Framework 4.8 eller senare**. Ingen installation av PowerShell 7 eller externa moduler behövs.

**GET med kropp, HTTP/2 och uttryckligt TLS 1.3-val stöds** genom Microsofts `WinHttpHandler`. JSON använder nu Json.NET med PowerShell 7-liknande typkonvertering. Packa upp hela ZIP-filen och behåll mappen `lib` med de sju medföljande DLL-filerna bredvid skriptet. WinHttpHandler laddas för GET-innehåll, HTTP/2 eller uttryckligt TLS 1.3; Json.NET laddas när ett svar ska JSON-konverteras. Funktionen kräver inte PowerShell 7.

Målet är så bred praktisk kompatibilitet som möjligt med `Invoke-RestMethod` i PowerShell **7.6.7**. Funktionen har samma ordinarie parameternamn, men den är en omimplementation och **inte en fullständigt identisk ersättare**. Begränsningarna nedan är en del av leveransen. Funktionaliteten har verifierats med lokala integrationstester i riktig Windows PowerShell 5.1; Microsofts fullständiga testsvit för originalcmdleten har inte körts.

## Kom igång

Öppna Windows PowerShell 5.1 i mappen där filerna ligger och läs in funktionen:

```powershell
. .\Invoke-RestMethod51.ps1

$result = Invoke-RestMethod51 -Uri 'https://api.example.com/items' `
    -Headers @{ Accept = 'application/json' } `
    -StatusCodeVariable status `
    -ResponseHeadersVariable responseHeaders
```

`api.example.com` är en exempeladress som ska bytas ut mot ditt API. Funktionen ändrar inga permanenta inställningar och ersätter inte den inbyggda cmdleten automatiskt. C#-hjälpkod kompileras i minnet vid första anropet. Miljön måste tillåta `Add-Type` och körning av skriptet enligt organisationens vanliga policy.

Om ett befintligt skript ska använda namnet `Invoke-RestMethod`, kan du uttryckligen lägga till detta i samma omfång som anropen:

```powershell
Set-Alias -Name Invoke-RestMethod -Value Invoke-RestMethod51 -Scope Local
```

Det ursprungliga kommandot går fortfarande att anropa som `Microsoft.PowerShell.Utility\Invoke-RestMethod`. Aliaset försvinner när det aktuella omfånget avslutas.

## Exempel

### GET med JSON-kropp

```powershell
$body = @{ query = 'test'; limit = 10 } | ConvertTo-Json -Compress

Invoke-RestMethod51 -Uri 'https://api.example.com/search' `
    -Method Get -ContentType 'application/json; charset=utf-8' -Body $body
```

Skicka JSON som sträng, byte-array, stream, HttpContent eller via `InFile`. En hashtabell direkt i `-Body` på GET fortsätter att bli frågeparametrar i URL:en, enligt originalcmdletens beteende. Servern och eventuella mellanliggande proxyservrar måste acceptera GET med kropp; HTTP definierar ingen generell betydelse för en sådan kropp. Se [HTTP-semantiken i RFC 9110](https://www.rfc-editor.org/rfc/rfc9110.html#section-9.3.1).

### HTTP/2 och TLS 1.3

```powershell
$result = Invoke-RestMethod51 -Uri 'https://api.example.com/items' `
    -HttpVersion '2.0' -SslProtocol Tls13 `
    -ResponseHttpVersionVariable actualHttpVersion

$actualHttpVersion  # 2.0 om servern faktiskt valde HTTP/2
```

`HttpVersion '2.0'` begär HTTP/2 men tillåter HTTP/1.1-fallback. Kontrollera `actualHttpVersion` om API:et kräver HTTP/2. **ResponseHttpVersionVariable är ett tillägg i den här funktionen**, inte en parameter i originalcmdleten. Den innehåller den verkliga svarsversionen som ett `System.Version`-objekt. `-Verbose` visar också svarsversionen.

HTTP/2 används här över HTTPS med ALPN och kräver stöd i Windows, servern och eventuella proxyservrar. WinHTTP-alternativet för HTTP/2 finns från Windows 10 version 1607 / Windows Server 2016. **TLS 1.3 kräver Windows 11 / Windows Server 2022 eller senare** och att protokollet är tillåtet i systemet och servern. `-SslProtocol Tls13` tillåter endast TLS 1.3: funktionen faller inte tyst tillbaka till TLS 1.2. För att uttryckligen tillåta båda anges `-SslProtocol Tls12,Tls13`. Utan `SslProtocol` används systemets standardval. Inga globala TLS-inställningar ändras. Se [WinHTTPs protokollalternativ](https://learn.microsoft.com/windows/win32/winhttp/option-flags#winhttp_option_enable_http_protocol) och [Schannels TLS-stöd](https://learn.microsoft.com/windows/win32/secauthn/protocols-in-tls-ssl--schannel-ssp-#tls-protocol-version-support).

### JSON-typer

JSON-parsningen använder Json.NET 13.0.4 och samma centrala inställningar som `JsonObject` vid PowerShell-taggen v7.6.7. Objekten projiceras till PowerShell-objekt i stället för att lämnas som JObject/JArray.

| JSON-värde | PowerShell/.NET-typ |
|---|---|
| Heltal inom Int64-intervallet | `System.Int64` |
| Större heltal | `System.Numerics.BigInteger` |
| Decimaltal och exponenttal | `System.Double` |
| ISO-tidsstämpel som parsern känner igen | `System.DateTime`, med RoundtripKind |
| Annan sträng | `System.String` |
| Objekt / array | PowerShell-objekt / `System.Object[]` |

Kommentarer, trailing commas och null hanteras av Json.NET. Metadata som `$type` förblir data och används inte för att skapa godtyckliga .NET-typer. Djupgränsen är 1024. Tomma egenskapsnamn eller namn som endast skiljer sig åt i skiftläge kan inte representeras som motsvarande PowerShell-objekt; svarstexten returneras då, enligt den testade REST-konverteringen i PowerShell 7.

### POST med JSON och Bearer-token

```powershell
$token = Read-Host 'Token' -AsSecureString
$body = @{ name = 'Test'; enabled = $true } | ConvertTo-Json

Invoke-RestMethod51 -Uri 'https://api.example.com/items' `
    -Method Post -ContentType 'application/json; charset=utf-8' `
    -Authentication Bearer -Token $token -Body $body
```

En hashtabell i `-Body` kodas som formulärdata. JSON ska, precis som med originalcmdleten, skapas uttryckligen med `ConvertTo-Json`.

### Läsa ett felsvar utan att kasta HTTP-fel

```powershell
$result = Invoke-RestMethod51 -Uri 'https://api.example.com/items/123' `
    -SkipHttpErrorCheck -StatusCodeVariable status

if ($status -eq 404) { $result }
```

Utan `-SkipHttpErrorCheck` innehåller felet HTTP-svaret och svarstexten:

```powershell
try {
    Invoke-RestMethod51 -Uri 'https://api.example.com/items/123'
} catch {
    $_.Exception.Response.StatusCode
    $_.ErrorDetails.Message
}
```

### Multipart, cookies, paginering och nedladdning

```powershell
Invoke-RestMethod51 -Uri 'https://api.example.com/upload' -Method Post -Form @{
    title = 'Rapport'
    file  = Get-Item -LiteralPath '.\rapport.pdf'
    tag   = @('intern', 'rapport')
}

$null = Invoke-RestMethod51 -Uri 'https://api.example.com/session' -SessionVariable apiSession
$items = Invoke-RestMethod51 -Uri 'https://api.example.com/items' -WebSession $apiSession

Invoke-RestMethod51 -Uri 'https://api.example.com/items' `
    -FollowRelLink -MaximumFollowRelLink 10 -MaximumRetryCount 3 -RetryIntervalSec 2

Invoke-RestMethod51 -Uri 'https://api.example.com/archive.zip' `
    -OutFile '.\archive.zip' -Resume
```

`MaximumFollowRelLink` begränsar det totala antalet hämtade sidor, inklusive den första. JSON-arrayer skickas som en enda array till nästa steg i pipelinen; använd exempelvis `ForEach-Object { $_ }` om elementen ska skickas vidare ett i taget.

## Stöd

| Område | Implementerat |
|---|---|
| HTTP | HTTP/1.0, HTTP/1.1 och förhandlad HTTP/2 över HTTPS, standardmetoder och `CustomMethod` / `CM`, headers, `SkipHeaderValidation`, User-Agent och keep-alive-inställning |
| Request body | Sträng, byte-array, XML, formulärkodad hashtabell, GET-frågeparametrar, **GET med kropp**, stream, `InFile`, `Form` med filer och listor, samt `HttpContent` |
| Svar | Json.NET med Int64/Double/BigInteger/DateTime, XML, vanlig text, standard-RSS/Atom, JSON-kommentarer, charset/BOM, gzip/deflate, status-, header- och HTTP-versionsvariabler |
| TLS | Systemstandard, TLS 1.2 och OS-beroende TLS 1.3; klientcertifikat och vanlig servercertifikatkontroll |
| Autentisering | Basic, Bearer/OAuth-token, `Credential`, `UseDefaultCredentials`, klientcertifikat och CurrentUser/My-thumbprint |
| Session | Windows PowerShells `WebRequestSession`, cookies, headers, autentiseringsuppgifter, transportinställningar och återanvänd HttpClient |
| Proxy | Explicit HTTP-proxy, proxyuppgifter, standardproxy, `NoProxy`, `HTTP_PROXY`, `HTTPS_PROXY`, `ALL_PROXY` och grundläggande `NO_PROXY` |
| Omdirigering | Gräns för antal, metodbyte för 301/302/303, bevarad kropp för 307/308, valfri bevarad metod/Authorization och spärr mot HTTPS till HTTP |
| Återförsök | HTTP 304 och 400–599, högsta antal återförsök, intervall och numerisk `Retry-After` vid 429 |
| Filer | Strömmande `OutFile`, `PassThru`, mappsökväg med filnamn från slutlig URI och `Resume` med Range / 206 / 416 |
| Övrigt | `FollowRelLink`, anslutnings-/svarstidsgränser, `TimeoutSec`-alias, `UseBasicParsing` som kompatibilitetsparameter |

Återförsök skickar om samma anrop, även POST. Använd inställningen där API:ets beteende tillåter detta.

## Kända skillnader mot 7.6.7

1. **Nyare transportfunktioner:** HTTP/3 och Unix-sockets stöds inte och ger tydliga fel. HTTP/2 och TLS 1.3 stöds med Windows-/serverkraven ovan. TLS använder systemets standard om inget anges; `Tls` och `Tls11` mappas till TLS 1.2 enligt 7.6-beteendet. Endast HTTP/HTTPS-adresser stöds.
2. **GET/HEAD/TRACE:** GET med kropp eller innehållsheaders använder automatiskt WinHttpHandler. Den transporten väljs också vid HTTP/2 eller uttryckligt TLS 1.3. HEAD och TRACE med kropp eller innehållsheaders avvisas fortfarande. Saknade DLL-filer ger tydliga fel. WinHTTP följer Windows HTTP-/TLS-beteende, vilket kan skilja sig i detaljer från PowerShell 7:s transport.
3. **JSON-parser:** De tidigare skillnaderna Int32/Decimal/strängdatum är åtgärdade. JSON använder den medföljande Json.NET-versionen och en egen PowerShell-projektion. Värden, CLR-typer, datumkind/ticks och flyttalsbitar har jämförts mot den installerade PowerShell 7.6.9-cmdleten i 28 testfall. Detta är inte ett bevis på identiskt beteende för varje tänkbart JSON-dokument eller varje skillnad mellan .NET Framework och modern .NET. Misslyckad konvertering ger svarstexten.
4. **Session och feltyper:** PowerShell 5.1:s sessionstyp används och kompletteras med egenskaperna `RestMethod51Settings` och `RestMethod51Transport`. Den är inte PowerShell 7:s sessionstyp och saknar dess `Dispose()`-metod. HTTP-fel använder `RestMethod51.HttpResponseException`, med en `Response` av typen `HttpResponseMessage` och svarstext i `ErrorDetails.Message`. Fel-ID:n, undantagskedjor och alla valideringsdetaljer är inte identiska med originalet. `StatusCodeVariable` och `ResponseHeadersVariable` sätts även när ett HTTP-fel kastas.
5. **Säkerhetsbeteende:** Certifikatkontroll sker normalt. `SkipCertificateCheck` gäller den aktuella transporten, utan att ändra `ServicePointManager` globalt. Omdirigeringar och efterföljande pagineringslänkar tar bort Authorization om inte `PreserveAuthorizationOnRedirect` används. Challenge-baserade inloggningsuppgifter appliceras inte på nytt efter dessa länkar. Sessionens autentiseringsuppgifter kräver också `AllowUnencryptedAuthentication` vid HTTP.
6. **Proxy och komprimering:** HTTP-proxyendpoints stöds; SOCKS och TLS-krypterad anslutning till själva proxyn stöds inte. `HTTPS_PROXY=http://proxy:8080` fungerar genom den vanliga HTTP-proxymekanismen. `NO_PROXY` stöder värdar, domänsuffix, portar, IPv6 och `*`, men inte CIDR. Brotli stöds inte. `TransferEncoding` sätter transportheaders och utför inte i sig komprimering av request body.
7. **Resurser och avbrott:** Svar som ska till pipelinen buffras i minnet. `OutFile` utan `PassThru` strömmas. `Body` som stream eller `HttpContent` buffras för att kunna skickas om; för stora uppladdningar används lämpligen `InFile`. Funktionen lämnar caller-ägda streams och HttpContent öppna. Ctrl+C kan reagera långsammare under ett blockerande nätverksanrop. PowerShell 5.1:s vanliga common parameters gäller; PowerShell 7:s `ProgressAction` och dess exakta progress-/debugutskrifter tillkommer inte.

När en sparad session inte längre behövs kan den cachade transporten frigöras så här:

```powershell
if ($apiSession.PSObject.Properties['RestMethod51Transport']) {
    $apiSession.RestMethod51Transport.Client.Dispose()
    $apiSession.PSObject.Properties.Remove('RestMethod51Transport')
}
```

Sessionens övriga tillstånd kan därefter användas igen; en ny transport skapas vid nästa anrop.

## Verifiering

Kör i Windows PowerShell 5.1:

```powershell
.\Test-Invoke-RestMethod51.ps1
```

Testerna startar tillfälliga HTTP-/HTTPS-servrar som endast lyssnar på `127.0.0.1`, skapar och tar bort sina egna testfiler och genererar ett tillfälligt självsignerat certifikat utan att ändra Windows certifikatlager. Ingen extern webbplats anropas. En lokal policy som hindrar loopback-trafik måste tillåta testprocessen för att integrationstesterna ska kunna köras.

Testerna täcker vanliga REST-anrop, representation och kodning, HTTP-fel, återförsök, omdirigeringar, sessioner, proxy, autentisering, paginering, multipart, filöverföring, tidsgränser och HTTPS. Windows-/domäninloggning och klientcertifikat mot en extern server ingår inte i den lokala verifieringen. Testerna bevisar inte fullständig överensstämmelse med varje detalj i originalet.

För TLS 1.3 på en stödd Windows-version och valfri jämförelse mot en installerad PowerShell 7:

```powershell
.\Test-Invoke-RestMethod51.ps1 -TestTls13 -PowerShell7Path 'C:\Program Files\PowerShell\7\pwsh.exe'
```

Separata protokolltester kontrollerar faktisk HTTP/2/TLS 1.3 med en lokal Kestrel-server. **Endast denna extra testserver kräver .NET 10 SDK/runtime; funktionen gör det inte.** Kör från paketmappen:

```powershell
$env:DOTNET_GENERATE_ASPNET_CERTIFICATE = 'false'
$env:DOTNET_CLI_HOME = Join-Path (Get-Location) 'work\dotnet-home'
$env:DOTNET_CLI_TELEMETRY_OPTOUT = '1'
dotnet build .\tests\ProtocolServer\ProtocolServer.csproj -o .\work\protocol-server
if ($LASTEXITCODE -ne 0) { throw 'Testservern kunde inte byggas.' }
.\tests\Test-Protocols.ps1 -ServerDll .\work\protocol-server\ProtocolServer.dll
```

Testservern använder ett eget tillfälligt självsignerat certifikat och lyssnar endast på loopback. Den installeras inte som tjänst och ändrar inget certifikatförtroende. Den stängs ned efter testet. Dessa tester kräver Windows med TLS 1.3-stöd.

## Referenser

- [Microsofts WinHttpHandler](https://learn.microsoft.com/dotnet/api/system.net.http.winhttphandler)
- [PowerShells JSON-konvertering vid taggen v7.6.7](https://github.com/PowerShell/PowerShell/blob/v7.6.7/src/Microsoft.PowerShell.Commands.Utility/commands/utility/WebCmdlet/JsonObject.cs)
- [Medföljande paketversioner och licenser](DEPENDENCIES.md)
- [Microsofts parameterdokumentation för Invoke-RestMethod 7.6](https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-restmethod?view=powershell-7.6)
- [Transportimplementationen vid taggen v7.6.7](https://github.com/PowerShell/PowerShell/blob/v7.6.7/src/Microsoft.PowerShell.Commands.Utility/commands/utility/WebCmdlet/Common/WebRequestPSCmdlet.Common.cs)
- [Svarshanteringen vid taggen v7.6.7](https://github.com/PowerShell/PowerShell/blob/v7.6.7/src/Microsoft.PowerShell.Commands.Utility/commands/utility/WebCmdlet/Common/InvokeRestMethodCommand.Common.cs)
