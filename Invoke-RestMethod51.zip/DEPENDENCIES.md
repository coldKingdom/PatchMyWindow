# Medföljande beroenden för JSON och WinHTTP

DLL-filerna hämtades från Microsofts och Newtonsofts officiella NuGet-paket. De ligger i `lib` och är avsedda för .NET Framework (`lib/net462` för Microsoft-paketen och `lib/net45` för Json.NET). Ingen global installation eller hämtning från nätet sker när funktionen körs. Behåll hela `lib` bredvid `Invoke-RestMethod51.ps1` när paketet flyttas. Json.NET används för svarskonverteringen; WinHttpHandler för GET-innehåll, HTTP/2 och uttryckligt TLS 1.3.

| Paket | Version |
|---|---|
| [Newtonsoft.Json](https://www.nuget.org/packages/Newtonsoft.Json/13.0.4) | 13.0.4 |
| [System.Net.Http.WinHttpHandler](https://www.nuget.org/packages/System.Net.Http.WinHttpHandler/10.0.14) | 10.0.14 |
| [Microsoft.Bcl.HashCode](https://www.nuget.org/packages/Microsoft.Bcl.HashCode/6.0.0) | 6.0.0 |
| [System.Buffers](https://www.nuget.org/packages/System.Buffers/4.6.1) | 4.6.1 |
| [System.Memory](https://www.nuget.org/packages/System.Memory/4.6.3) | 4.6.3 |
| [System.Numerics.Vectors](https://www.nuget.org/packages/System.Numerics.Vectors/4.6.1) | 4.6.1 |
| [System.Runtime.CompilerServices.Unsafe](https://www.nuget.org/packages/System.Runtime.CompilerServices.Unsafe/6.1.2) | 6.1.2 |

Paketmetadata med versioner, upphovsrätt och beroenden finns i `licenses/*.nuspec`. Paketen anger MIT-licens. Se `licenses/MIT-LICENSE.txt`, `licenses/newtonsoft-LICENSE.md` och den medföljande `winhttphandler-THIRD-PARTY-NOTICES.TXT` för licens- och tredjepartsinformation.

Windows PowerShell 5.1 delar laddade .NET-assemblies med andra moduler i processen. Om en annan modul redan har laddat en inkompatibel version av samma beroende kan ett nytt PowerShell-fönster behövas. Den lokala verifieringen genomfördes i nya PowerShell 5.1-processer.
