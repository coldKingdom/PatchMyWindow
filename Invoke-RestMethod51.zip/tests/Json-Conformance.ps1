#requires -Version 5.1
param([Parameter(Mandatory)][string]$Uri, [Parameter(Mandatory)][string]$OutputPath, [switch]$Compatibility)
$ErrorActionPreference='Stop'
$command='Microsoft.PowerShell.Utility\Invoke-RestMethod'
if ($Compatibility) { . (Join-Path (Split-Path -Parent $PSScriptRoot) 'Invoke-RestMethod51.ps1'); $command='Invoke-RestMethod51' }
function Signature([AllowNull()][object]$Value) {
    if ($null -eq $Value) { return 'null' }
    if ($Value -is [array]) {
        $items=foreach($item in $Value) { Signature $item }
        return 'array[' + ($items -join ',') + ']'
    }
    if ($Value -is [System.Management.Automation.PSCustomObject]) {
        $items=foreach($property in $Value.PSObject.Properties) { $property.Name + '=' + (Signature $property.Value) }
        return 'object{' + ($items -join ',') + '}'
    }
    $type=$Value.GetType().FullName
    if ($Value -is [datetime]) { return $type + '/' + $Value.Kind + ':' + $Value.Ticks }
    if ($Value -is [string]) { return $type + ':' + [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($Value)) }
    if ($Value -is [double]) { return $type + ':0x' + [BitConverter]::DoubleToInt64Bits($Value).ToString('X16') }
    return $type + ':' + $Value.ToString()
}
$cases=[ordered]@{
    Integers='{"small":1,"negative":-2,"max":9223372036854775807,"min":-9223372036854775808}'
    BigIntegers='{"huge":9223372036854775808,"negative":-9223372036854775809,"larger":1234567890123456789012345678901234567890}'
    FloatingPoint='{"real":1.25,"exponent":1e3,"tiny":1e-300,"negativeZero":-0.0,"precise":1.234567890123456789}'
    NegativeZeros='{"items":[-0.0,1,-0e3,{"n":-0.0}],"root":-0.0}'
    Dates='{"utc":"2020-01-01T00:00:00Z","offset":"2020-01-01T00:00:00+02:30","unspecified":"2020-01-01T00:00:00","dateOnly":"2020-01-01"}'
    FractionalDate='{"date":"2020-01-01T00:00:00.1234567Z"}'
    MicrosoftDate='{"date":"/Date(1577836800000)/"}'
    Scalars='[true,false,null,1,1.25,"text"]'
    Nested='{"a":[1,[2,[],{}],null,{"n":1.25}]}'
    EmptyArray='[]'
    EmptyObject='{}'
    Null='null'
    False='false'
    Number='42'
    Decimal='1.25'
    RootString='"text"'
    RootDate='"2020-01-01T00:00:00Z"'
    Metadata='{"$type":"System.IO.FileInfo, mscorlib","$id":"one","$values":[1,2]}'
    Duplicate='{"a":1,"a":2}'
    Casing='{"a":1,"A":2}'
    EmptyName='{"":1}'
    Comments='{/* c */"url":"https://test/a//b","n":1}'
    OnlyComment='/* comment only */'
    TrailingComma='{"a":1,}'
    SingleQuoted="{'a':1}"
    NonFinite='[NaN,Infinity,-Infinity]'
    Malformed='{not json'
    Empty=''
}
$records=foreach($case in $cases.GetEnumerator()) {
    $value=& $command -Uri $Uri -NoProxy -Method Post -ContentType 'application/json; charset=utf-8' -Body $case.Value
    [pscustomobject]@{ Name=$case.Key; Signature=(Signature $value) }
}
[IO.File]::WriteAllText($OutputPath, ($records | ConvertTo-Json -Depth 10 -Compress), (New-Object Text.UTF8Encoding -ArgumentList $false))
