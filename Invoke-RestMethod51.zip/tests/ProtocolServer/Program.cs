using System.Net;
using System.Security.Authentication;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text.Json;
using Microsoft.AspNetCore.Connections.Features;
using Microsoft.AspNetCore.Hosting.Server;
using Microsoft.AspNetCore.Hosting.Server.Features;
using Microsoft.AspNetCore.Server.Kestrel.Core;
using Microsoft.AspNetCore.Server.Kestrel.Https;

// Local test fixture only. It neither installs a certificate nor listens outside loopback.
if (args.Length != 1) throw new ArgumentException("Supply an output path for endpoint information.");
using var key = RSA.Create(2048);
var request = new CertificateRequest("CN=localhost", key, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
var names = new SubjectAlternativeNameBuilder();
names.AddDnsName("localhost"); names.AddIpAddress(IPAddress.Loopback);
request.CertificateExtensions.Add(names.Build());
using var generated = request.CreateSelfSigned(DateTimeOffset.UtcNow.AddMinutes(-5), DateTimeOffset.UtcNow.AddDays(1));
using var certificate = X509CertificateLoader.LoadPkcs12(generated.Export(X509ContentType.Pfx), null);
using var clientKey = RSA.Create(2048);
var clientRequest = new CertificateRequest("CN=local-mtls-client", clientKey, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
clientRequest.CertificateExtensions.Add(new X509KeyUsageExtension(X509KeyUsageFlags.DigitalSignature, true));
clientRequest.CertificateExtensions.Add(new X509EnhancedKeyUsageExtension(new OidCollection { new Oid("1.3.6.1.5.5.7.3.2") }, false));
using var clientCertificate = clientRequest.CreateSelfSigned(DateTimeOffset.UtcNow.AddMinutes(-5), DateTimeOffset.UtcNow.AddDays(1));
var clientPfx = Path.Combine(Path.GetDirectoryName(Path.GetFullPath(args[0]))!, "mtls-client.pfx");
await File.WriteAllBytesAsync(clientPfx, clientCertificate.Export(X509ContentType.Pfx, "local-mtls-tests"));
var builder = WebApplication.CreateBuilder(Array.Empty<string>());
builder.Logging.ClearProviders();
builder.Logging.AddConsole();
builder.Logging.SetMinimumLevel(LogLevel.Debug);
builder.WebHost.ConfigureKestrel(server => {
    server.Listen(IPAddress.Loopback, 0, endpoint => {
        endpoint.Protocols = HttpProtocols.Http1AndHttp2;
        endpoint.UseHttps(https => { https.ServerCertificate = certificate; https.SslProtocols = SslProtocols.Tls12 | SslProtocols.Tls13; });
    });
    server.Listen(IPAddress.Loopback, 0, endpoint => {
        endpoint.Protocols = HttpProtocols.Http1;
        endpoint.UseHttps(https => { https.ServerCertificate = certificate; https.SslProtocols = SslProtocols.Tls12; });
    });
    for (int i = 0; i < 2; i++) {
        server.Listen(IPAddress.Loopback, 0, endpoint => {
            endpoint.Protocols = HttpProtocols.Http1AndHttp2;
            endpoint.UseHttps(https => {
                https.ServerCertificate = certificate;
                https.SslProtocols = SslProtocols.Tls12 | SslProtocols.Tls13;
                https.ClientCertificateMode = ClientCertificateMode.RequireCertificate;
                // The isolated fixture trusts exactly its own temporary client certificate.
                https.ClientCertificateValidation = (cert, chain, errors) => cert.Thumbprint == clientCertificate.Thumbprint;
            });
        });
    }
});
await using var app = builder.Build();
string[] addresses = Array.Empty<string>();
app.Run(async context => {
    var body = await new StreamReader(context.Request.Body).ReadToEndAsync();
    var tls = context.Features.Get<ITlsHandshakeFeature>();
    var peerCertificate = await context.Connection.GetClientCertificateAsync();
    if (context.Request.Path == "/login" || context.Request.Path == "/login-public") {
        if (peerCertificate?.Thumbprint != clientCertificate.Thumbprint) { context.Response.StatusCode = 403; return; }
        context.Response.Cookies.Append("mtls_session", "fixture-session", new CookieOptions { HttpOnly = true, Secure = true, Path = "/" });
        context.Response.Redirect((context.Request.Path == "/login" ? addresses[3] : addresses[1]) + "/protected");
        return;
    }
    bool authenticated = context.Request.Cookies["mtls_session"] == "fixture-session";
    if (context.Request.Path == "/protected" && !authenticated) {
        context.Response.StatusCode = 401;
        await context.Response.WriteAsJsonAsync(new { error = "session cookie required" });
        return;
    }
    await context.Response.WriteAsJsonAsync(new {
        protocol = context.Request.Protocol,
        tls = tls?.Protocol.ToString(),
        method = context.Request.Method,
        body,
        authenticated,
        clientCertificate = peerCertificate?.Thumbprint,
        connection = context.Connection.Id
    });
});
await app.StartAsync();
addresses = app.Services.GetRequiredService<IServer>().Features.Get<IServerAddressesFeature>()!.Addresses.ToArray();
await File.WriteAllTextAsync(args[0] + ".tmp", JsonSerializer.Serialize(new { http2 = addresses[0], http1 = addresses[1], mtlsLogin = addresses[2], mtlsTarget = addresses[3], clientPfx, clientThumbprint = clientCertificate.Thumbprint }));
File.Move(args[0] + ".tmp", args[0]);
while (!File.Exists(args[0] + ".stop") && !app.Lifetime.ApplicationStopping.IsCancellationRequested) await Task.Delay(100);
await app.StopAsync();
