using System.Net;
using System.Security.Authentication;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text.Json;
using Microsoft.AspNetCore.Connections.Features;
using Microsoft.AspNetCore.Hosting.Server;
using Microsoft.AspNetCore.Hosting.Server.Features;
using Microsoft.AspNetCore.Server.Kestrel.Core;

// Local test fixture only. It neither installs a certificate nor listens outside loopback.
if (args.Length != 1) throw new ArgumentException("Supply an output path for endpoint information.");
using var key = RSA.Create(2048);
var request = new CertificateRequest("CN=localhost", key, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
var names = new SubjectAlternativeNameBuilder();
names.AddDnsName("localhost"); names.AddIpAddress(IPAddress.Loopback);
request.CertificateExtensions.Add(names.Build());
using var generated = request.CreateSelfSigned(DateTimeOffset.UtcNow.AddMinutes(-5), DateTimeOffset.UtcNow.AddDays(1));
using var certificate = X509CertificateLoader.LoadPkcs12(generated.Export(X509ContentType.Pfx), null);
var builder = WebApplication.CreateBuilder(Array.Empty<string>());
builder.Logging.ClearProviders();
builder.Logging.AddConsole();
builder.Logging.SetMinimumLevel(LogLevel.Debug);
builder.WebHost.ConfigureKestrel(server => {
    server.Listen(IPAddress.Loopback, 0, endpoint => {
        endpoint.Protocols = HttpProtocols.Http1AndHttp2;
        endpoint.UseHttps(https => { https.ServerCertificate = certificate; https.SslProtocols = SslProtocols.Tls12 | SslProtocols.Tls13; });
    });
    server.Listen(IPAddress.Loopback, 0, endpoint => {
        endpoint.Protocols = HttpProtocols.Http1;
        endpoint.UseHttps(https => { https.ServerCertificate = certificate; https.SslProtocols = SslProtocols.Tls12; });
    });
});
await using var app = builder.Build();
app.Run(async context => {
    var body = await new StreamReader(context.Request.Body).ReadToEndAsync();
    var tls = context.Features.Get<ITlsHandshakeFeature>();
    await context.Response.WriteAsJsonAsync(new {
        protocol = context.Request.Protocol,
        tls = tls?.Protocol.ToString(),
        method = context.Request.Method,
        body
    });
});
await app.StartAsync();
var addresses = app.Services.GetRequiredService<IServer>().Features.Get<IServerAddressesFeature>()!.Addresses.ToArray();
await File.WriteAllTextAsync(args[0] + ".tmp", JsonSerializer.Serialize(new { http2 = addresses[0], http1 = addresses[1] }));
File.Move(args[0] + ".tmp", args[0]);
while (!File.Exists(args[0] + ".stop") && !app.Lifetime.ApplicationStopping.IsCancellationRequested) await Task.Delay(100);
await app.StopAsync();
