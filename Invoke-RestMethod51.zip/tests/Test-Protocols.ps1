#requires -Version 5.1
param([Parameter(Mandatory)][string]$ServerDll)
$ErrorActionPreference='Stop'
. (Join-Path (Split-Path -Parent $PSScriptRoot) 'Invoke-RestMethod51.ps1')
$temp=Join-Path ([IO.Path]::GetTempPath()) ([guid]::NewGuid().ToString())
[void][IO.Directory]::CreateDirectory($temp)
$infoPath=Join-Path $temp 'endpoints.json'
$process=$null
$script:passed=0; $script:failed=0
function Assert($Condition, [string]$Message='Assertion failed') { if(-not $Condition) { throw $Message } }
function Expect-Error([scriptblock]$Action) { $caught=$false; try { & $Action | Out-Null } catch { $caught=$true }; Assert $caught 'Expected the request to fail.' }
function Test([string]$Name,[scriptblock]$Action) {
    try { & $Action; $script:passed++; Write-Host "PASS $Name" }
    catch { $script:failed++; Write-Host "FAIL $Name : $_"; Write-Host $_.Exception.ToString(); Write-Host $_.ScriptStackTrace }
}
try {
    $dotnet=(Get-Command dotnet.exe -ErrorAction Stop).Source
    $dll=(Resolve-Path -LiteralPath $ServerDll).ProviderPath
    $process=Start-Process -FilePath $dotnet -ArgumentList @(('"{0}"' -f $dll),('"{0}"' -f $infoPath)) -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $temp 'stdout.txt') -RedirectStandardError (Join-Path $temp 'stderr.txt')
    $deadline=[DateTime]::UtcNow.AddSeconds(30)
    while(-not (Test-Path -LiteralPath $infoPath)) {
        if($process.HasExited) { throw ('Protocol fixture exited: '+(Get-Content -Raw -LiteralPath (Join-Path $temp 'stderr.txt'))) }
        if([DateTime]::UtcNow -gt $deadline) { throw 'Protocol fixture did not become ready.' }
        Start-Sleep -Milliseconds 100
    }
    $endpoints=Get-Content -Raw -LiteralPath $infoPath | ConvertFrom-Json
    Write-Host ("Local fixtures: {0}; {1}" -f $endpoints.http2,$endpoints.http1)
    $listeners=[Net.NetworkInformation.IPGlobalProperties]::GetIPGlobalProperties().GetActiveTcpListeners()
    Write-Host ("Fixture process running: {0}; port listed: {1}" -f (-not $process.HasExited), [bool]($listeners.Port -contains ([uri]$endpoints.http2).Port))
    Test 'Actual HTTP/2 over TLS 1.2' {
        $r=Invoke-RestMethod51 $endpoints.http2 -NoProxy -HttpVersion '2.0' -SslProtocol Tls12 -SkipCertificateCheck -ResponseHttpVersionVariable version -ConnectionTimeoutSeconds 5
        Assert ($version -eq [version]'2.0' -and $r.protocol -eq 'HTTP/2' -and $r.tls -eq 'Tls12')
        Write-Host ("Observed: HTTP/{0}, {1}" -f $version,$r.tls)
    }
    Test 'Actual HTTP/2 and TLS 1.3 with GET JSON body' {
        $r=Invoke-RestMethod51 $endpoints.http2 -NoProxy -HttpVersion '2.0' -SslProtocol Tls13 -SkipCertificateCheck -Body '{"get":true}' -ContentType application/json -ResponseHttpVersionVariable version -ConnectionTimeoutSeconds 5
        Assert ($version -eq [version]'2.0' -and $r.protocol -eq 'HTTP/2' -and $r.tls -eq 'Tls13' -and $r.method -eq 'GET' -and $r.body -eq '{"get":true}')
        Write-Host ("Observed: HTTP/{0}, {1}, {2}, {3}" -f $version,$r.tls,$r.method,$r.body)
    }
    Test 'HTTP/2 and TLS 1.3 with POST body' {
        $r=Invoke-RestMethod51 $endpoints.http2 -NoProxy -HttpVersion '2.0' -SslProtocol Tls13 -SkipCertificateCheck -Method Post -Body 'post body' -ResponseHttpVersionVariable version -ConnectionTimeoutSeconds 5
        Assert ($version -eq [version]'2.0' -and $r.protocol -eq 'HTTP/2' -and $r.tls -eq 'Tls13' -and $r.method -eq 'POST' -and $r.body -eq 'post body')
    }
    Test 'HTTP/2 preference reports HTTP/1.1 fallback honestly' {
        $r=Invoke-RestMethod51 $endpoints.http1 -NoProxy -HttpVersion '2.0' -SslProtocol Tls12 -SkipCertificateCheck -ResponseHttpVersionVariable version -ConnectionTimeoutSeconds 5
        Assert ($version -eq [version]'1.1' -and $r.protocol -eq 'HTTP/1.1')
    }
    Test 'TLS 1.3-only choice does not fall back to TLS 1.2' { Expect-Error { Invoke-RestMethod51 $endpoints.http1 -NoProxy -HttpVersion '2.0' -SslProtocol Tls13 -SkipCertificateCheck -ConnectionTimeoutSeconds 5 } }
    Test 'HTTP/2 TLS 1.3 still validates certificates by default' { Expect-Error { Invoke-RestMethod51 $endpoints.http2 -NoProxy -HttpVersion '2.0' -SslProtocol Tls13 -ConnectionTimeoutSeconds 5 } }
} finally {
    if($process -and -not $process.HasExited) {
        [IO.File]::WriteAllText($infoPath+'.stop','stop')
        if(-not $process.WaitForExit(5000)) { Stop-Process -Id $process.Id; $process.WaitForExit() }
    }
    if($script:failed) { Get-Content -LiteralPath (Join-Path $temp 'stdout.txt'); Get-Content -LiteralPath (Join-Path $temp 'stderr.txt') }
    if([IO.Path]::GetFullPath($temp).StartsWith([IO.Path]::GetFullPath([IO.Path]::GetTempPath()),[StringComparison]::OrdinalIgnoreCase)) { Remove-Item -LiteralPath $temp -Recurse -Force }
}
Write-Host ("Protocol results: {0} passed, {1} failed; PowerShell {2}" -f $script:passed,$script:failed,$PSVersionTable.PSVersion)
if($script:failed) { exit 1 }
